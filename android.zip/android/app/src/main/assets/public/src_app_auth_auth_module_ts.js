(self["webpackChunkpaylo"] = self["webpackChunkpaylo"] || []).push([["src_app_auth_auth_module_ts"],{

/***/ 7377:
/*!*************************************************************!*\
  !*** ./node_modules/@capacitor/app/dist/esm/definitions.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);

//# sourceMappingURL=definitions.js.map

/***/ }),

/***/ 2138:
/*!*******************************************************!*\
  !*** ./node_modules/@capacitor/app/dist/esm/index.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "App": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 8384);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 7377);

const App = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('App', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_app_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 6141)).then(m => new m.AppWeb()),
});


//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2276:
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthRoutingModule": () => (/* binding */ AuthRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _auth_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.component */ 980);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login/login.component */ 8146);
/* harmony import */ var _registration_registration_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./registration/registration.component */ 7462);
/* harmony import */ var _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./welcome/welcome.component */ 3966);







const routes = [
    {
        path: '',
        component: _auth_component__WEBPACK_IMPORTED_MODULE_0__.AuthComponent,
        children: [
            {
                path: '',
                component: _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_3__.WelcomeComponent
            },
            {
                path: 'login',
                component: _login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent
            },
            {
                path: 'registration',
                component: _registration_registration_component__WEBPACK_IMPORTED_MODULE_2__.RegistrationComponent
            }
        ]
    }
];
let AuthRoutingModule = class AuthRoutingModule {
};
AuthRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
    })
], AuthRoutingModule);



/***/ }),

/***/ 980:
/*!****************************************!*\
  !*** ./src/app/auth/auth.component.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthComponent": () => (/* binding */ AuthComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_auth_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./auth.component.html */ 7852);
/* harmony import */ var _auth_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.component.scss */ 6559);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let AuthComponent = class AuthComponent {
    constructor() { }
    ngOnInit() { }
};
AuthComponent.ctorParameters = () => [];
AuthComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-auth',
        template: _raw_loader_auth_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_auth_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AuthComponent);



/***/ }),

/***/ 1674:
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthModule": () => (/* binding */ AuthModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth-routing.module */ 2276);
/* harmony import */ var _auth_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.component */ 980);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login/login.component */ 8146);
/* harmony import */ var _registration_registration_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./registration/registration.component */ 7462);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./welcome/welcome.component */ 3966);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);










let AuthModule = class AuthModule {
};
AuthModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [_auth_component__WEBPACK_IMPORTED_MODULE_1__.AuthComponent, _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_4__.WelcomeComponent, _login_login_component__WEBPACK_IMPORTED_MODULE_2__.LoginComponent, _registration_registration_component__WEBPACK_IMPORTED_MODULE_3__.RegistrationComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _auth_routing_module__WEBPACK_IMPORTED_MODULE_0__.AuthRoutingModule
        ]
    })
], AuthModule);



/***/ }),

/***/ 8146:
/*!***********************************************!*\
  !*** ./src/app/auth/login/login.component.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_login_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login.component.html */ 1561);
/* harmony import */ var _login_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss */ 5529);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/global-functions.service */ 4646);







let LoginComponent = class LoginComponent {
    constructor(fb, globalService, auth) {
        this.fb = fb;
        this.globalService = globalService;
        this.auth = auth;
    }
    ngOnInit() {
        this.createForms();
    }
    createForms() {
        this.loginForm = this.fb.group({
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.email]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(8)]]
        });
    }
    onLoginSubmit() {
        if (this.loginForm.valid) {
            this.auth.signIn(this.loginForm.value);
        }
        else {
            // this.loginForm.markAsDirty();
            this.loginForm.markAllAsTouched();
        }
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_3__.GlobalFunctionsService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-login',
        template: _raw_loader_login_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LoginComponent);



/***/ }),

/***/ 7462:
/*!*************************************************************!*\
  !*** ./src/app/auth/registration/registration.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistrationComponent": () => (/* binding */ RegistrationComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_registration_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./registration.component.html */ 4027);
/* harmony import */ var _registration_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registration.component.scss */ 6819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/global-functions.service */ 4646);
/* harmony import */ var src_app_services_loader_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/loader.service */ 8555);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/environments/environment */ 2340);










let RegistrationComponent = class RegistrationComponent {
    constructor(fb, globalService, auth, loader) {
        this.fb = fb;
        this.globalService = globalService;
        this.auth = auth;
        this.loader = loader;
        this.apiurl = src_environments_environment__WEBPACK_IMPORTED_MODULE_5__.environment.apiUrl;
        this.inviteCodeObservable = new rxjs__WEBPACK_IMPORTED_MODULE_6__.BehaviorSubject(false);
        this.inviteCodeValid = false;
        this.confirmPasswordValid = false;
    }
    ngOnInit() {
        this.createForms();
        this.registerForm.controls.invitecode.valueChanges.subscribe((code) => {
            if (code.length === 12) {
                this.loader.showLoader();
                console.log(code);
                this.getInviteCode(code);
            }
        });
        this.inviteCodeObservable.asObservable().subscribe((value) => {
            if (value) {
                this.inviteCodeValid = true;
                console.log(true);
            }
            else {
                this.inviteCodeValid = false;
                console.log(false);
                this.registerForm.controls.invitecode.markAsDirty;
            }
        });
        this.registerForm.controls.confirmPassword.valueChanges.subscribe((value) => {
            if (value !== this.registerForm.controls.password.value) {
                this.confirmPasswordValid = false;
            }
            else {
                this.confirmPasswordValid = true;
            }
        });
    }
    getInviteCode(code) {
        const demoCode = 'ASAA07121988';
        this.auth.afs.collection('inviteCodes', (ref) => ref.where('code', '==', code)).valueChanges().subscribe((codes) => {
            console.log(codes);
            if (codes && codes.length > 0) {
                this.inviteCodeObservable.next(true);
            }
            else {
                this.inviteCodeObservable.next(false);
            }
            this.loader.stopLoader();
        });
    }
    createForms() {
        this.registerForm = this.fb.group({
            name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.email]],
            mobile: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(10)]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(8)]],
            confirmPassword: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(8)]],
            invitecode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.minLength(8)]]
        });
    }
    onRegisterSubmit() {
        if (!this.registerForm.invalid && this.confirmPasswordValid && this.inviteCodeValid) {
            const number = this.registerForm.controls.mobile.value;
            // this.registerForm.controls.mobile.setValue('+91'+number);
            this.registerForm.addControl('newMobile', new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl('+91' + number));
            console.log(this.registerForm.value);
            this.auth.registration(this.registerForm.value);
        }
    }
};
RegistrationComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_3__.GlobalFunctionsService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_loader_service__WEBPACK_IMPORTED_MODULE_4__.LoaderService }
];
RegistrationComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-registration',
        template: _raw_loader_registration_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_registration_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], RegistrationComponent);



/***/ }),

/***/ 3966:
/*!***************************************************!*\
  !*** ./src/app/auth/welcome/welcome.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WelcomeComponent": () => (/* binding */ WelcomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_welcome_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./welcome.component.html */ 8718);
/* harmony import */ var _welcome_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./welcome.component.scss */ 7640);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/app */ 2138);






// const { App } = Plugins;
let WelcomeComponent = class WelcomeComponent {
    constructor(platform, routerOutlet) {
        this.platform = platform;
        this.routerOutlet = routerOutlet;
        this.platform.backButton.subscribeWithPriority(1, () => {
            if (!this.routerOutlet.canGoBack()) {
                _capacitor_app__WEBPACK_IMPORTED_MODULE_2__.App.exitApp();
            }
        });
    }
    ngOnInit() { }
};
WelcomeComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRouterOutlet }
];
WelcomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-welcome',
        template: _raw_loader_welcome_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_welcome_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], WelcomeComponent);



/***/ }),

/***/ 6559:
/*!******************************************!*\
  !*** ./src/app/auth/auth.component.scss ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#auth {\n  background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);\n  background-size: 400% 400%;\n  animation: gradient 15s ease infinite;\n  min-height: 100vh;\n}\n\n@keyframes gradient {\n  0% {\n    background-position: 0% 50%;\n  }\n  50% {\n    background-position: 100% 50%;\n  }\n  100% {\n    background-position: 0% 50%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGguY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyx1RUFBQTtFQUNBLDBCQUFBO0VBQ0EscUNBQUE7RUFDQyxpQkFBQTtBQUNGOztBQUVBO0VBQ0M7SUFDQywyQkFBQTtFQUNBO0VBQ0Q7SUFDQyw2QkFBQTtFQUNBO0VBQ0Q7SUFDQywyQkFBQTtFQUNBO0FBQ0YiLCJmaWxlIjoiYXV0aC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNhdXRoIHtcblx0YmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KC00NWRlZywgI2VlNzc1MiwgI2U3M2M3ZSwgIzIzYTZkNSwgIzIzZDVhYik7XG5cdGJhY2tncm91bmQtc2l6ZTogNDAwJSA0MDAlO1xuXHRhbmltYXRpb246IGdyYWRpZW50IDE1cyBlYXNlIGluZmluaXRlO1xuICBtaW4taGVpZ2h0OiAxMDB2aDtcbn1cblxuQGtleWZyYW1lcyBncmFkaWVudCB7XG5cdDAlIHtcblx0XHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiAwJSA1MCU7XG5cdH1cblx0NTAlIHtcblx0XHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiAxMDAlIDUwJTtcblx0fVxuXHQxMDAlIHtcblx0XHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiAwJSA1MCU7XG5cdH1cbn1cbiJdfQ== */");

/***/ }),

/***/ 5529:
/*!*************************************************!*\
  !*** ./src/app/auth/login/login.component.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb2dpbi5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 6819:
/*!***************************************************************!*\
  !*** ./src/app/auth/registration/registration.component.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3RyYXRpb24uY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 7640:
/*!*****************************************************!*\
  !*** ./src/app/auth/welcome/welcome.component.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".mainLogo {\n  max-width: 150px;\n  margin: auto;\n  height: 100%;\n  margin-top: 30%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlbGNvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQUNGIiwiZmlsZSI6IndlbGNvbWUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbkxvZ28ge1xuICBtYXgtd2lkdGg6IDE1MHB4O1xuICBtYXJnaW46IGF1dG87XG4gIGhlaWdodDogMTAwJTtcbiAgbWFyZ2luLXRvcDogMzAlO1xufVxuIl19 */");

/***/ }),

/***/ 7852:
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.component.html ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content fullscreen=\"true\" class=\"ion-no-padding\">\n  <div id=\"auth\" class=\"ion-padding\">\n    <router-outlet></router-outlet>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ 1561:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-button size=\"large\" fill=\"clear\" color=\"light\" class=\"ion-no-padding ion-padding-end\" (click)=\"globalService.back()\">\n  <ion-icon size=\"large\" name=\"chevron-back-outline\"></ion-icon>\n</ion-button>\n<!-- <ion-buttons slot=\"start\">\n  <ion-back-button fill=\"clear\" color=\"light\" class=\"ion-no-padding ion-padding-end\" text=\"\" icon=\"chevron-back-outline\" defaultHref=\"auth\"></ion-back-button>\n</ion-buttons> -->\n\n<div class=\"authMiddlePanel ion-padding-top\">\n  <ion-text color=\"light\">\n    <h1>\n      Welcome Back\n    </h1>\n  </ion-text>\n</div>\n\n<div id=\"bottomPanel\" class=\"waves authForm\">\n  <form [formGroup]=\"loginForm\" (ngSubmit)=\"onLoginSubmit()\">\n  <ion-grid>\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"12\" size-md=\"6\">\n        <ion-item lines=\"none\" class=\"customInputItem\">\n          <ion-icon name=\"person-circle-outline\"></ion-icon>\n          <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n          *ngIf=\"loginForm.controls.email.valid\"></ion-icon>\n          <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n          *ngIf=\"loginForm.controls.email.invalid && (loginForm.controls.email.dirty || loginForm.controls.email.touched)\"></ion-icon>\n          <ion-input formControlName=\"email\" placeholder=\"Email\" type=\"email\" autocomplete=\"loginEMail\" autocorrect=\"off\"></ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"12\" size-md=\"6\">\n        <ion-item lines=\"none\" class=\"customInputItem\">\n          <ion-icon name=\"lock-closed-outline\"></ion-icon>\n          <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n          *ngIf=\"loginForm.controls.password.valid\"></ion-icon>\n          <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n          *ngIf=\"loginForm.controls.password.invalid && (loginForm.controls.password.dirty || loginForm.controls.password.touched)\"></ion-icon>\n          <ion-input formControlName=\"password\" placeholder=\"Password\" type=\"password\" autocomplete=\"loginPassword\" autocorrect=\"off\"></ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"12\">\n        <ion-text><a>Forget password?</a></ion-text>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"12\">\n        <ion-button type=\"submit\" shape=\"round\" class=\"shadow\" color=\"primary\" expand=\"block\">Log in</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  </form>\n</div>\n");

/***/ }),

/***/ 4027:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/registration/registration.component.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-button size=\"large\" fill=\"clear\" color=\"light\" class=\"ion-no-padding ion-padding-end\"\n  (click)=\"globalService.back()\">\n  <ion-icon size=\"large\" name=\"chevron-back-outline\"></ion-icon>\n</ion-button>\n<!-- <ion-buttons slot=\"start\">\n  <ion-back-button fill=\"clear\" color=\"light\" class=\"ion-no-padding ion-padding-end\" text=\"\" icon=\"chevron-back-outline\" defaultHref=\"auth\"></ion-back-button>\n</ion-buttons> -->\n\n<div class=\"authMiddlePanel ion-padding-top\">\n  <ion-text color=\"light\">\n    <h1>\n      Create Account\n    </h1>\n  </ion-text>\n</div>\n\n<div id=\"bottomPanel\" class=\"waves authForm\">\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"onRegisterSubmit()\">\n    <ion-grid>\n      <ion-row class=\"ion-align-items-center\">\n        <ion-col size=\"12\" size-md=\"6\">\n          <ion-item lines=\"none\" class=\"customInputItem\">\n            <ion-icon name=\"person-circle-outline\"></ion-icon>\n            <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n              *ngIf=\"registerForm.controls.name.valid\"></ion-icon>\n            <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n              *ngIf=\"registerForm.controls.name.invalid && (registerForm.controls.name.dirty || registerForm.controls.name.touched)\">\n            </ion-icon>\n            <ion-input formControlName=\"name\" placeholder=\"Full Name\" autocomplete=\"newName\"></ion-input>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"12\" size-md=\"6\">\n          <ion-item lines=\"none\" class=\"customInputItem\">\n            <ion-icon name=\"at-outline\"></ion-icon>\n            <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n              *ngIf=\"registerForm.controls.email.valid\"></ion-icon>\n            <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n              *ngIf=\"registerForm.controls.email.invalid && (registerForm.controls.email.dirty || registerForm.controls.email.touched)\">\n            </ion-icon>\n            <ion-input formControlName=\"email\" placeholder=\"Email\" type=\"email\" autocomplete=\"newEmail\"></ion-input>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"12\" size-md=\"6\">\n          <ion-item lines=\"none\" class=\"customInputItem\">\n            <ion-icon name=\"call-outline\"></ion-icon>\n            <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n              *ngIf=\"registerForm.controls.mobile.valid\"></ion-icon>\n            <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n              *ngIf=\"registerForm.controls.mobile.invalid && (registerForm.controls.mobile.dirty || registerForm.controls.mobile.touched)\">\n            </ion-icon>\n            <ion-input formControlName=\"mobile\" placeholder=\"Mobile\" type=\"number\" minlength=\"10\" maxlength=\"10\" autocomplete=\"newMobile\"></ion-input>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"12\" size-md=\"6\">\n          <ion-item lines=\"none\" class=\"customInputItem\">\n            <ion-icon name=\"lock-closed-outline\"></ion-icon>\n            <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n              *ngIf=\"registerForm.controls.password.valid\"></ion-icon>\n            <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n              *ngIf=\"registerForm.controls.password.invalid && (registerForm.controls.password.dirty || registerForm.controls.password.touched)\">\n            </ion-icon>\n            <ion-input formControlName=\"password\" placeholder=\"Password\" type=\"password\" autocomplete=\"newPassword\"></ion-input>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"12\" size-md=\"6\">\n          <ion-item lines=\"none\" class=\"customInputItem\">\n            <ion-icon name=\"lock-closed-outline\"></ion-icon>\n            <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n              *ngIf=\"registerForm.controls.confirmPassword.valid && confirmPasswordValid\"></ion-icon>\n            <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n              *ngIf=\"(registerForm.controls.confirmPassword.invalid || !confirmPasswordValid) && (registerForm.controls.confirmPassword.dirty || registerForm.controls.confirmPassword.touched)\">\n            </ion-icon>\n            <ion-input formControlName=\"confirmPassword\" placeholder=\"Confirm Password\" type=\"password\"\n              autocomplete=\"newConfirmPassword\"></ion-input>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"12\" size-md=\"6\">\n          <ion-item lines=\"none\" class=\"customInputItem\">\n            <ion-icon name=\"ticket-outline\"></ion-icon>\n            <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\"\n              *ngIf=\"registerForm.controls.invitecode.valid && inviteCodeValid\"></ion-icon>\n            <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\"\n              *ngIf=\"(registerForm.controls.invitecode.invalid || !inviteCodeValid) && (registerForm.controls.invitecode.dirty || registerForm.controls.invitecode.touched)\">\n            </ion-icon>\n            <ion-input formControlName=\"invitecode\" placeholder=\"Invite Code\" autocapitalize=\"characters\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"ion-align-items-center\">\n        <ion-col size=\"12\">\n          <ion-button shape=\"round\" class=\"shadow\" color=\"primary\" expand=\"block\" type=\"submit\"\n            [disabled]=\"registerForm.invalid || !confirmPasswordValid || !inviteCodeValid\">Sign up</ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n</div>\n");

/***/ }),

/***/ 8718:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/welcome/welcome.component.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-text class=\"ion-text-center\">\n  <ion-img class=\"mainLogo\" src=\"../../../assets/logos/PL-white.png\"></ion-img>\n</ion-text>\n\n<div id=\"bottomPanel\">\n  <ion-grid>\n    <ion-row class=\"ion-align-items-center\">\n      <ion-text color=\"light\" class=\"ion-padding\">\n        <h1> PayLo <br/> रोज़ का रोज़गार </h1>\n      </ion-text>\n    </ion-row>\n    <ion-row class=\"ion-align-items-center\">\n      <ion-col size=\"12\" size-md=\"6\">\n        <ion-button shape=\"round\" class=\"shadow\" color=\"light\" expand=\"block\" routerLink=\"/auth/login\">Log in</ion-button>\n      </ion-col>\n      <ion-col size=\"12\" size-md=\"6\">\n        <ion-button shape=\"round\" class=\"shadow\" color=\"light\" fill=\"outline\" expand=\"block\" routerLink=\"/auth/registration\">Sign up</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</div>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_auth_auth_module_ts.js.map