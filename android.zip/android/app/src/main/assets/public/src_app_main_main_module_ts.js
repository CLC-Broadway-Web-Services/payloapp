(self["webpackChunkpaylo"] = self["webpackChunkpaylo"] || []).push([["src_app_main_main_module_ts"],{

/***/ 8274:
/*!**********************************************************************************!*\
  !*** ./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-storage.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AngularFireStorage": () => (/* binding */ AngularFireStorage),
/* harmony export */   "AngularFireStorageModule": () => (/* binding */ AngularFireStorageModule),
/* harmony export */   "BUCKET": () => (/* binding */ BUCKET),
/* harmony export */   "GetDownloadURLPipe": () => (/* binding */ GetDownloadURLPipe),
/* harmony export */   "GetDownloadURLPipeModule": () => (/* binding */ GetDownloadURLPipeModule),
/* harmony export */   "MAX_OPERATION_RETRY_TIME": () => (/* binding */ MAX_OPERATION_RETRY_TIME),
/* harmony export */   "MAX_UPLOAD_RETRY_TIME": () => (/* binding */ MAX_UPLOAD_RETRY_TIME),
/* harmony export */   "createStorageRef": () => (/* binding */ createStorageRef),
/* harmony export */   "createUploadTask": () => (/* binding */ createUploadTask),
/* harmony export */   "fromTask": () => (/* binding */ fromTask)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 9165);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 5917);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 9412);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 4395);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 8002);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 9746);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 3190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire */ 57);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/storage */ 2325);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 8583);









// Things aren't working great, I'm having to put in a lot of work-arounds for what
// appear to be Firebase JS SDK bugs https://github.com/firebase/firebase-js-sdk/issues/4158

function fromTask(task) {
    return new rxjs__WEBPACK_IMPORTED_MODULE_1__.Observable(subscriber => {
        const progress = (snap) => subscriber.next(snap);
        const error = e => subscriber.error(e);
        const complete = () => subscriber.complete();
        // emit the current snapshot, so they don't have to wait for state_changes
        // to fire next... this is stale if the task is no longer running :(
        progress(task.snapshot);
        const unsub = task.on('state_changed', progress);
        // it turns out that neither task snapshot nor 'state_changed' fire the last
        // snapshot before completion, the one with status 'success" and 100% progress
        // so let's use the promise form of the task for that
        task.then(snapshot => {
            progress(snapshot);
            complete();
        }, e => {
            // TODO investigate, again this is stale, we never fire a canceled or error it seems
            progress(task.snapshot);
            error(e);
        });
        // on's type if Function, rather than () => void, need to wrap
        return function unsubscribe() {
            unsub();
        };
    }).pipe(
    // deal with sync emissions from first emitting `task.snapshot`, this makes sure
    // that if the task is already finished we don't emit the old running state
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.debounceTime)(0));
}

/**
 * Create an AngularFireUploadTask from a regular UploadTask from the Storage SDK.
 * This method creates an observable of the upload and returns on object that provides
 * multiple methods for controlling and monitoring the file upload.
 */
function createUploadTask(task) {
    const inner$ = fromTask(task);
    return {
        task,
        then: task.then.bind(task),
        catch: task.catch.bind(task),
        pause: task.pause.bind(task),
        cancel: task.cancel.bind(task),
        resume: task.resume.bind(task),
        snapshotChanges: () => inner$,
        percentageChanges: () => inner$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(s => s.bytesTransferred / s.totalBytes * 100))
    };
}

/**
 * Create an AngularFire wrapped Storage Reference. This object
 * creates observable methods from promise based methods.
 */
function createStorageRef(ref, schedulers, keepUnstableUntilFirst) {
    return {
        getDownloadURL: () => (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(undefined).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.observeOn)(schedulers.outsideAngular), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.switchMap)(() => ref.getDownloadURL()), keepUnstableUntilFirst),
        getMetadata: () => (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(undefined).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.observeOn)(schedulers.outsideAngular), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.switchMap)(() => ref.getMetadata()), keepUnstableUntilFirst),
        delete: () => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(ref.delete()),
        child: (path) => createStorageRef(ref.child(path), schedulers, keepUnstableUntilFirst),
        updateMetadata: (meta) => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(ref.updateMetadata(meta)),
        put: (data, metadata) => {
            const task = ref.put(data, metadata);
            return createUploadTask(task);
        },
        putString: (data, format, metadata) => {
            const task = ref.putString(data, format, metadata);
            return createUploadTask(task);
        },
        listAll: () => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(ref.listAll())
    };
}

const BUCKET = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.InjectionToken('angularfire2.storageBucket');
const MAX_UPLOAD_RETRY_TIME = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.InjectionToken('angularfire2.storage.maxUploadRetryTime');
const MAX_OPERATION_RETRY_TIME = new _angular_core__WEBPACK_IMPORTED_MODULE_8__.InjectionToken('angularfire2.storage.maxOperationRetryTime');
/**
 * AngularFireStorage Service
 *
 * This service is the main entry point for this feature module. It provides
 * an API for uploading and downloading binary files from Cloud Storage for
 * Firebase.
 */
class AngularFireStorage {
    constructor(options, nameOrConfig, storageBucket, 
    // tslint:disable-next-line:ban-types
    platformId, zone, maxUploadRetryTime, maxOperationRetryTime) {
        this.schedulers = new _angular_fire__WEBPACK_IMPORTED_MODULE_9__["ɵAngularFireSchedulers"](zone);
        this.keepUnstableUntilFirst = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_9__["ɵkeepUnstableUntilFirstFactory"])(this.schedulers);
        const app = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_9__["ɵfirebaseAppFactory"])(options, zone, nameOrConfig);
        this.storage = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_9__["ɵfetchInstance"])(`${app.name}.storage.${storageBucket}`, 'AngularFireStorage', app, () => {
            const storage = zone.runOutsideAngular(() => app.storage(storageBucket || undefined));
            if (maxUploadRetryTime) {
                storage.setMaxUploadRetryTime(maxUploadRetryTime);
            }
            if (maxOperationRetryTime) {
                storage.setMaxOperationRetryTime(maxOperationRetryTime);
            }
            return storage;
        }, [maxUploadRetryTime, maxOperationRetryTime]);
    }
    ref(path) {
        return createStorageRef(this.storage.ref(path), this.schedulers, this.keepUnstableUntilFirst);
    }
    refFromURL(path) {
        return createStorageRef(this.storage.refFromURL(path), this.schedulers, this.keepUnstableUntilFirst);
    }
    upload(path, data, metadata) {
        const storageRef = this.storage.ref(path);
        const ref = createStorageRef(storageRef, this.schedulers, this.keepUnstableUntilFirst);
        return ref.put(data, metadata);
    }
}
AngularFireStorage.ɵfac = function AngularFireStorage_Factory(t) { return new (t || AngularFireStorage)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_OPTIONS), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_APP_NAME, 8), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](BUCKET, 8), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_8__.PLATFORM_ID), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](MAX_UPLOAD_RETRY_TIME, 8), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](MAX_OPERATION_RETRY_TIME, 8)); };
/** @nocollapse */ AngularFireStorage.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({ factory: function AngularFireStorage_Factory() { return new AngularFireStorage(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_OPTIONS), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_APP_NAME, 8), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](BUCKET, 8), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_8__.PLATFORM_ID), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](MAX_UPLOAD_RETRY_TIME, 8), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](MAX_OPERATION_RETRY_TIME, 8)); }, token: AngularFireStorage, providedIn: "any" });
/** @nocollapse */
AngularFireStorage.ctorParameters = () => [
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_OPTIONS,] }] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_APP_NAME,] }] },
    { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [BUCKET,] }] },
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [_angular_core__WEBPACK_IMPORTED_MODULE_8__.PLATFORM_ID,] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.NgZone },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [MAX_UPLOAD_RETRY_TIME,] }] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject, args: [MAX_OPERATION_RETRY_TIME,] }] }
];
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵsetClassMetadata"](AngularFireStorage, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable,
        args: [{
                providedIn: 'any'
            }]
    }], function () { return [{ type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject,
                args: [_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_OPTIONS]
            }] }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject,
                args: [_angular_fire__WEBPACK_IMPORTED_MODULE_9__.FIREBASE_APP_NAME]
            }] }, { type: String, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject,
                args: [BUCKET]
            }] }, { type: Object, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject,
                args: [_angular_core__WEBPACK_IMPORTED_MODULE_8__.PLATFORM_ID]
            }] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.NgZone }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject,
                args: [MAX_UPLOAD_RETRY_TIME]
            }] }, { type: undefined, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Optional
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Inject,
                args: [MAX_OPERATION_RETRY_TIME]
            }] }]; }, null); })();

/** to be used with in combination with | async */
class GetDownloadURLPipe {
    constructor(storage, cdr) {
        this.storage = storage;
        this.asyncPipe = new _angular_common__WEBPACK_IMPORTED_MODULE_10__.AsyncPipe(cdr);
    }
    transform(path) {
        if (path !== this.path) {
            this.path = path;
            this.downloadUrl$ = this.storage.ref(path).getDownloadURL();
        }
        return this.asyncPipe.transform(this.downloadUrl$);
    }
    ngOnDestroy() {
        this.asyncPipe.ngOnDestroy();
    }
}
GetDownloadURLPipe.ɵfac = function GetDownloadURLPipe_Factory(t) { return new (t || GetDownloadURLPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](AngularFireStorage, 16), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_8__.ChangeDetectorRef, 16)); };
GetDownloadURLPipe.ɵpipe = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefinePipe"]({ name: "getDownloadURL", type: GetDownloadURLPipe, pure: false });
/** @nocollapse */
GetDownloadURLPipe.ctorParameters = () => [
    { type: AngularFireStorage },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ChangeDetectorRef }
];
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵsetClassMetadata"](GetDownloadURLPipe, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Pipe,
        args: [{
                name: 'getDownloadURL',
                pure: false
            }]
    }], function () { return [{ type: AngularFireStorage }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ChangeDetectorRef }]; }, null); })();
class GetDownloadURLPipeModule {
}
GetDownloadURLPipeModule.ɵfac = function GetDownloadURLPipeModule_Factory(t) { return new (t || GetDownloadURLPipeModule)(); };
GetDownloadURLPipeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({ type: GetDownloadURLPipeModule });
GetDownloadURLPipeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({});
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵsetClassMetadata"](GetDownloadURLPipeModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule,
        args: [{
                declarations: [GetDownloadURLPipe],
                exports: [GetDownloadURLPipe]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](GetDownloadURLPipeModule, { declarations: [GetDownloadURLPipe], exports: [GetDownloadURLPipe] }); })();

class AngularFireStorageModule {
}
AngularFireStorageModule.ɵfac = function AngularFireStorageModule_Factory(t) { return new (t || AngularFireStorageModule)(); };
AngularFireStorageModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({ type: AngularFireStorageModule });
AngularFireStorageModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({ providers: [AngularFireStorage], imports: [GetDownloadURLPipeModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵsetClassMetadata"](AngularFireStorageModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule,
        args: [{
                exports: [GetDownloadURLPipeModule],
                providers: [AngularFireStorage]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](AngularFireStorageModule, { exports: [GetDownloadURLPipeModule] }); })();

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=angular-fire-storage.js.map

/***/ }),

/***/ 3509:
/*!***************************************************************!*\
  !*** ./node_modules/@capacitor/share/dist/esm/definitions.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);

//# sourceMappingURL=definitions.js.map

/***/ }),

/***/ 6380:
/*!*********************************************************!*\
  !*** ./node_modules/@capacitor/share/dist/esm/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Share": () => (/* binding */ Share)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 8384);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 3509);

const Share = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Share', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_share_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 4648)).then(m => new m.ShareWeb()),
});


//# sourceMappingURL=index.js.map

/***/ }),

/***/ 2325:
/*!*********************************************************!*\
  !*** ./node_modules/firebase/storage/dist/index.esm.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _firebase_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/storage */ 990);

//# sourceMappingURL=index.esm.js.map


/***/ }),

/***/ 8136:
/*!*******************************************************************************************!*\
  !*** ./node_modules/ngx-circular-progress/__ivy_ngcc__/fesm2015/ngx-circular-progress.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NgxCircularProgressComponent": () => (/* binding */ NgxCircularProgressComponent),
/* harmony export */   "NgxCircularProgressModule": () => (/* binding */ NgxCircularProgressModule),
/* harmony export */   "NgxCircularProgressService": () => (/* binding */ NgxCircularProgressService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 8583);







const _c0 = function (a0) { return { "over50": a0 }; };
const _c1 = function (a0) { return { "color": a0 }; };
const _c2 = function (a0) { return { "background-color": a0 }; };
const _c3 = function (a0, a1) { return { "transform": a0, "border-color": a1 }; };
let NgxCircularProgressService = class NgxCircularProgressService {
    constructor() {
    }
};
NgxCircularProgressService.ɵfac = function NgxCircularProgressService_Factory(t) { return new (t || NgxCircularProgressService)(); };
NgxCircularProgressService.ɵprov = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({ factory: function NgxCircularProgressService_Factory() { return new NgxCircularProgressService(); }, token: NgxCircularProgressService, providedIn: "root" });

let NgxCircularProgressComponent = class NgxCircularProgressComponent {
    constructor() {
        this.percent = 25;
        this.color = "blue";
        this.txtColor = "black";
        this.bln = false;
    }
    ngOnInit() {
        this.degree = this.percent * 3.6;
        this.bln = this.percent > 50;
        this.degStr = `rotate(${this.degree}deg)`;
    }
};
NgxCircularProgressComponent.ɵfac = function NgxCircularProgressComponent_Factory(t) { return new (t || NgxCircularProgressComponent)(); };
NgxCircularProgressComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NgxCircularProgressComponent, selectors: [["ngx-circular-progress"]], inputs: { percent: ["value", "percent"], color: "color", txtColor: "txtColor" }, decls: 6, vars: 14, consts: [[1, "progress-circle", 3, "ngClass"], [3, "ngStyle"], [1, "left-half-clipper"], [1, "first50-bar", 3, "ngStyle"], [1, "value-bar", 3, "ngStyle"]], template: function NgxCircularProgressComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](5, _c0, ctx.bln));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](7, _c1, ctx.txtColor));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.percent, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](9, _c2, ctx.color));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](11, _c3, ctx.degStr, ctx.color));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle], styles: [".progress-circle[_ngcontent-%COMP%]{font-size:20px;margin:20px;position:relative;padding:0;width:5em;height:5em;background-color:#f2e9e1;border-radius:50%;line-height:5em;display:inline-block}.progress-circle[_ngcontent-%COMP%]:after{border:none;position:absolute;top:.35em;left:.35em;text-align:center;display:block;border-radius:50%;width:4.3em;height:4.3em;background-color:#fff;content:\" \"}.progress-circle[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{position:absolute;line-height:5em;width:5em;text-align:center;display:block;z-index:2}.left-half-clipper[_ngcontent-%COMP%]{border-radius:50%;width:5em;height:5em;position:absolute;clip:rect(0,5em,5em,2.5em)}.progress-circle.over50[_ngcontent-%COMP%]   .left-half-clipper[_ngcontent-%COMP%]{clip:rect(auto,auto,auto,auto)}.value-bar[_ngcontent-%COMP%]{position:absolute;clip:rect(0,2.5em,5em,0);width:5em;height:5em;border-radius:50%;border-width:.45em;border-style:solid;box-sizing:border-box}.progress-circle.over50[_ngcontent-%COMP%]   .first50-bar[_ngcontent-%COMP%]{position:absolute;clip:rect(0,5em,5em,2.5em);border-radius:50%;width:5em;height:5em}.progress-circle[_ngcontent-%COMP%]:not(.over50)   .first50-bar[_ngcontent-%COMP%]{display:none}"] });
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Input)('value')
], NgxCircularProgressComponent.prototype, "percent", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Input)('color')
], NgxCircularProgressComponent.prototype, "color", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Input)('txtColor')
], NgxCircularProgressComponent.prototype, "txtColor", void 0);

let NgxCircularProgressModule = class NgxCircularProgressModule {
};
NgxCircularProgressModule.ɵfac = function NgxCircularProgressModule_Factory(t) { return new (t || NgxCircularProgressModule)(); };
NgxCircularProgressModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: NgxCircularProgressModule });
NgxCircularProgressModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule
        ]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxCircularProgressService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return []; }, null); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxCircularProgressComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
        args: [{
                selector: 'ngx-circular-progress',
                template: "<div class=\"progress-circle\" [ngClass]=\"{'over50': bln}\">\n    <span [ngStyle]=\"{'color': txtColor}\">{{percent}}%</span>\n    <div class=\"left-half-clipper\">\n       <div class=\"first50-bar\" [ngStyle]=\"{'background-color': color}\"></div>\n       <div class=\"value-bar\" [ngStyle]=\"{'transform': degStr, 'border-color': color}\"></div>\n    </div>\n</div>\n",
                styles: [".progress-circle{font-size:20px;margin:20px;position:relative;padding:0;width:5em;height:5em;background-color:#f2e9e1;border-radius:50%;line-height:5em;display:inline-block}.progress-circle:after{border:none;position:absolute;top:.35em;left:.35em;text-align:center;display:block;border-radius:50%;width:4.3em;height:4.3em;background-color:#fff;content:\" \"}.progress-circle span{position:absolute;line-height:5em;width:5em;text-align:center;display:block;z-index:2}.left-half-clipper{border-radius:50%;width:5em;height:5em;position:absolute;clip:rect(0,5em,5em,2.5em)}.progress-circle.over50 .left-half-clipper{clip:rect(auto,auto,auto,auto)}.value-bar{position:absolute;clip:rect(0,2.5em,5em,0);width:5em;height:5em;border-radius:50%;border-width:.45em;border-style:solid;box-sizing:border-box}.progress-circle.over50 .first50-bar{position:absolute;clip:rect(0,5em,5em,2.5em);border-radius:50%;width:5em;height:5em}.progress-circle:not(.over50) .first50-bar{display:none}"]
            }]
    }], function () { return []; }, { percent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
            args: ['value']
        }], color: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
            args: ['color']
        }], txtColor: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
            args: ['txtColor']
        }] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NgxCircularProgressModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
        args: [{
                declarations: [NgxCircularProgressComponent],
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule
                ],
                exports: [NgxCircularProgressComponent]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](NgxCircularProgressModule, { declarations: function () { return [NgxCircularProgressComponent]; }, imports: function () { return [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]; }, exports: function () { return [NgxCircularProgressComponent]; } }); })();

/*
 * Public API Surface of ngx-circular-progress
 */

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=ngx-circular-progress.js.map

/***/ }),

/***/ 4395:
/*!***********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/debounceTime.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "debounceTime": () => (/* binding */ debounceTime)
/* harmony export */ });
/* harmony import */ var _Subscriber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Subscriber */ 7393);
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../scheduler/async */ 3637);


function debounceTime(dueTime, scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.async) {
    return (source) => source.lift(new DebounceTimeOperator(dueTime, scheduler));
}
class DebounceTimeOperator {
    constructor(dueTime, scheduler) {
        this.dueTime = dueTime;
        this.scheduler = scheduler;
    }
    call(subscriber, source) {
        return source.subscribe(new DebounceTimeSubscriber(subscriber, this.dueTime, this.scheduler));
    }
}
class DebounceTimeSubscriber extends _Subscriber__WEBPACK_IMPORTED_MODULE_1__.Subscriber {
    constructor(destination, dueTime, scheduler) {
        super(destination);
        this.dueTime = dueTime;
        this.scheduler = scheduler;
        this.debouncedSubscription = null;
        this.lastValue = null;
        this.hasValue = false;
    }
    _next(value) {
        this.clearDebounce();
        this.lastValue = value;
        this.hasValue = true;
        this.add(this.debouncedSubscription = this.scheduler.schedule(dispatchNext, this.dueTime, this));
    }
    _complete() {
        this.debouncedNext();
        this.destination.complete();
    }
    debouncedNext() {
        this.clearDebounce();
        if (this.hasValue) {
            const { lastValue } = this;
            this.lastValue = null;
            this.hasValue = false;
            this.destination.next(lastValue);
        }
    }
    clearDebounce() {
        const debouncedSubscription = this.debouncedSubscription;
        if (debouncedSubscription !== null) {
            this.remove(debouncedSubscription);
            debouncedSubscription.unsubscribe();
            this.debouncedSubscription = null;
        }
    }
}
function dispatchNext(subscriber) {
    subscriber.debouncedNext();
}
//# sourceMappingURL=debounceTime.js.map

/***/ }),

/***/ 3012:
/*!************************************************************!*\
  !*** ./src/app/main/dashboard/dashboard-routing.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardRoutingModule": () => (/* binding */ DashboardRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 6894);




const routes = [
    {
        path: '',
        component: _dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent
    }
];
let DashboardRoutingModule = class DashboardRoutingModule {
};
DashboardRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], DashboardRoutingModule);



/***/ }),

/***/ 6894:
/*!*******************************************************!*\
  !*** ./src/app/main/dashboard/dashboard.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardComponent": () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./dashboard.component.html */ 1295);
/* harmony import */ var _dashboard_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.component.scss */ 6342);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/global-functions.service */ 4646);
/* harmony import */ var src_app_services_taskview_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/taskview.service */ 8986);







let DashboardComponent = class DashboardComponent {
    constructor(global, taskService, auth) {
        this.global = global;
        this.taskService = taskService;
        this.auth = auth;
        this.weeklyTasksPercentage = 0;
        this.weeklyTasksCompleted = 0;
        this.weeklyTasksTotal = 0;
    }
    ngOnInit() {
        this.auth.userTasks.asObservable().subscribe((tasks) => {
            if (tasks && tasks.length > 0) {
                console.log(tasks);
                const completedTasks = tasks.filter((task) => {
                    return task.isApproved;
                });
                const totalTasksLength = tasks.length; // 100
                const completedTasksLength = completedTasks.length; // 40
                const tasksPercentage = totalTasksLength / 100;
                // this.weeklyTasksPercentage = Math.ceil(tasksPercentage*completedTasksLength);
                this.weeklyTasksPercentage = tasksPercentage * completedTasksLength;
                this.weeklyTasksCompleted = completedTasks.length;
                this.weeklyTasksTotal = tasks.length;
            }
        });
    }
    taskActionSheet(data) {
        this.taskService.toggleTaskView(data);
    }
};
DashboardComponent.ctorParameters = () => [
    { type: src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_3__.GlobalFunctionsService },
    { type: src_app_services_taskview_service__WEBPACK_IMPORTED_MODULE_4__.TaskviewService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
DashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-dashboard',
        template: _raw_loader_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_dashboard_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DashboardComponent);



/***/ }),

/***/ 5929:
/*!****************************************************!*\
  !*** ./src/app/main/dashboard/dashboard.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardModule": () => (/* binding */ DashboardModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard-routing.module */ 3012);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.component */ 6894);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 4466);
/* harmony import */ var ngx_circular_progress__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-circular-progress */ 8136);








let DashboardModule = class DashboardModule {
};
DashboardModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_dashboard_component__WEBPACK_IMPORTED_MODULE_1__.DashboardComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
            ngx_circular_progress__WEBPACK_IMPORTED_MODULE_7__.NgxCircularProgressModule,
            _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_0__.DashboardRoutingModule
        ]
    })
], DashboardModule);



/***/ }),

/***/ 976:
/*!**********************************************************!*\
  !*** ./src/app/main/earnings/earnings-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EarningsRoutingModule": () => (/* binding */ EarningsRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _earnings_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./earnings.component */ 2827);




const routes = [
    {
        path: '',
        component: _earnings_component__WEBPACK_IMPORTED_MODULE_0__.EarningsComponent
    }
];
let EarningsRoutingModule = class EarningsRoutingModule {
};
EarningsRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], EarningsRoutingModule);



/***/ }),

/***/ 2827:
/*!*****************************************************!*\
  !*** ./src/app/main/earnings/earnings.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EarningsComponent": () => (/* binding */ EarningsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_earnings_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./earnings.component.html */ 6410);
/* harmony import */ var _earnings_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./earnings.component.scss */ 6940);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_interfaces_wallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/wallet */ 6845);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/global-functions.service */ 4646);
/* harmony import */ var src_app_services_loader_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/loader.service */ 8555);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 8002);











let EarningsComponent = class EarningsComponent {
    constructor(global, fb, alertController, loader, auth) {
        this.global = global;
        this.fb = fb;
        this.alertController = alertController;
        this.loader = loader;
        this.auth = auth;
        // myWallet: Wallet = {
        //   id: '',
        //   totalPoints: 0,
        //   currentPoints: 0,
        //   totalConvertedPoints: 0,
        //   convertionRateInitial: 1,
        //   totalConvertedAmount: 0,
        //   withdrawlAmount: 0,
        //   userUpi: '',
        //   uid: ''
        // };
        this.myWallet = new src_app_interfaces_wallet__WEBPACK_IMPORTED_MODULE_2__.Wallet;
        this.showUpiForm = false;
        this.showModule = 'wallet'; // history / convertions / wallet
        // test variables only
        this.detailsTrue = true;
        this.testUserId = "8jv3uzHBppfj0TesSzRjbD07KLp2";
    }
    ngOnInit() {
        this.walletForm = this.fb.group({
            points: [50, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.min(50)]],
            convertionRate: [this.myWallet.convertionRateInitial, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]],
            uid: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]],
            amount: [50, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.min(50)]],
            isRequested: [true, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]],
            upi_id: [this.myWallet.userUpi, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]],
            timeCreated: [''],
        });
        this.upiForm = this.fb.group({
            userUpi: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]]
        });
        this.walletForm.controls.points.valueChanges.subscribe((points) => {
            if (points >= 50) {
                this.walletForm.controls.amount.patchValue(points);
            }
        });
        this.auth.userData.asObservable().subscribe((userdata) => {
            if (userdata) {
                // console.log(userdata);
                // this.userData = userdata;
                this.auth.userWallet.asObservable().subscribe((wallet) => {
                    console.log(wallet);
                    if (wallet) {
                        this.myWallet = wallet;
                        this.walletForm.controls.uid.patchValue(wallet.uid);
                        this.walletForm.controls.upi_id.patchValue(wallet.userUpi);
                        this.walletForm.controls.convertionRate.patchValue(wallet.convertionRateInitial);
                        this.upiForm.controls.userUpi.patchValue(wallet.userUpi);
                        // this.auth.afs.collection('pointsConvertion', ref => ref.where('uid', '==', wallet.uid))
                        //   .valueChanges().subscribe((convertions: Withdrawl[]) => {
                        //     console.log(convertions)
                        //     this.convertionWithdrawls = convertions;
                        //   })
                        console.log('started pointsConvertions');
                        this.auth.afs.collection('pointsConvertion', ref => ref.where('uid', '==', wallet.uid))
                            .snapshotChanges().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)((actions) => {
                            return actions.map(a => {
                                const data = a.payload.doc.data();
                                const id = a.payload.doc.id;
                                const thisData = Object.assign(Object.assign({}, data), { id });
                                return thisData;
                            });
                        })).subscribe((data) => {
                            console.log(data);
                            this.convertionWithdrawls = data;
                        });
                        // this.auth.afs.collection('points', ref => ref.where('referedUserUid', '==', wallet.uid).limit(20))
                        // .valueChanges().subscribe((pointsData: Points[])=> {
                        //   console.log(pointsData)
                        //   this.pointsHistory = pointsData;
                        // })
                    }
                });
            }
        });
        this.walletForm.valueChanges.subscribe((form) => {
            console.log(form);
        });
    }
    modulePageChange(event) {
        this.showModule = event.target.value;
    }
    showAlertForConvertion(convertionId) {
        const filteration = this.convertionWithdrawls.filter((c => { return c.id == convertionId; }));
        if (filteration.length > 0) {
            const list = filteration[0];
            // completed
            if (list.isRequested && list.isCompleted && !list.isRejected && !list.isOnHold) {
                this.showCompleteAlert(list);
            }
            // rejected
            if (list.isRequested && !list.isCompleted && list.isRejected && !list.isOnHold) {
                this.showRejectedAlert(list);
            }
            // on-hold
            if (list.isRequested && !list.isCompleted && !list.isRejected && list.isOnHold) {
                this.showOnHoldAlert(list);
            }
        }
    }
    showCompleteAlert(data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Transaction Details',
                translucent: true,
                message: data.transactionId,
                buttons: [{
                        text: 'Okay',
                        handler: () => {
                            console.log('Confirm Okay');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    showRejectedAlert(data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Reject reason',
                translucent: true,
                message: data.rejectReason,
                buttons: [{
                        text: 'Okay',
                        handler: () => {
                            console.log('Confirm Okay');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    showOnHoldAlert(data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'On-Hold Details',
                translucent: true,
                message: data.onHoldReason,
                buttons: [{
                        text: 'Okay',
                        handler: () => {
                            console.log('Confirm Okay');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    saveUpiId() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (this.upiForm.valid && this.myWallet.userUpi !== this.upiForm.controls.userUpi.value) {
                this.loader.showLoader();
                this.auth.afs.doc(`pointsWallet/${this.myWallet.uid}`).set(this.upiForm.value, { merge: true }).then(() => {
                    // this.auth.afs.doc(`pointsWallet/${this.testUserId}`).set(this.upiForm.value, { merge: true }).then(() => {
                    this.loader.stopLoader();
                }).catch((err) => {
                    alert(err.message);
                    this.loader.stopLoader();
                });
            }
        });
    }
    createWithdrawlRequest() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (this.walletForm.valid && this.myWallet.uid) {
                this.walletForm.controls.timeCreated.patchValue(Date.now());
                this.loader.showLoader();
                console.log(this.walletForm.valid);
                this.auth.afs.collection(`pointsConvertion`).add(this.walletForm.value).then((response) => {
                    console.log(response);
                    // new data
                    const pointsToDeduct = this.walletForm.controls.points.value;
                    const amountToDeduct = this.walletForm.controls.amount.value;
                    const newData = {
                        currentPoints: this.myWallet.currentPoints - pointsToDeduct,
                        totalConvertedPoints: this.myWallet.totalConvertedPoints + pointsToDeduct,
                        totalConvertedAmount: this.myWallet.totalConvertedAmount + amountToDeduct,
                        uid: this.myWallet.uid,
                        userUpi: this.myWallet.userUpi,
                        convertionRateInitial: this.myWallet.convertionRateInitial
                    };
                    this.auth.afs.doc(`pointsWallet/${this.myWallet.uid}`).set(newData, { merge: true })
                        .then((response) => {
                        console.log(response);
                        this.loader.stopLoader();
                    })
                        .catch((err) => {
                        console.log(err);
                        this.loader.stopLoader();
                        alert(err.message);
                    });
                })
                    .catch((err) => {
                    this.loader.stopLoader();
                    alert(err.message);
                });
            }
        });
    }
};
EarningsComponent.ctorParameters = () => [
    { type: src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_4__.GlobalFunctionsService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: src_app_services_loader_service__WEBPACK_IMPORTED_MODULE_5__.LoaderService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService }
];
EarningsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-earnings',
        template: _raw_loader_earnings_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_earnings_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EarningsComponent);



/***/ }),

/***/ 4149:
/*!**************************************************!*\
  !*** ./src/app/main/earnings/earnings.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EarningsModule": () => (/* binding */ EarningsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _earnings_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./earnings-routing.module */ 976);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 4466);
/* harmony import */ var _earnings_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./earnings.component */ 2827);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);








let EarningsModule = class EarningsModule {
};
EarningsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_earnings_component__WEBPACK_IMPORTED_MODULE_2__.EarningsComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
            _earnings_routing_module__WEBPACK_IMPORTED_MODULE_0__.EarningsRoutingModule
        ]
    })
], EarningsModule);



/***/ }),

/***/ 9853:
/*!*********************************************!*\
  !*** ./src/app/main/main-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainRoutingModule": () => (/* binding */ MainRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _main_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main.component */ 2284);




const routes = [
    {
        path: '',
        component: _main_component__WEBPACK_IMPORTED_MODULE_0__.MainComponent,
        children: [
            {
                path: 'dashboard',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./dashboard/dashboard.module */ 5929)).then(m => m.DashboardModule), data: { animation: 'FilterPage' }
            },
            {
                path: 'tasks',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./tasks/tasks.module */ 4618)).then(m => m.TasksModule), data: { animation: 'FilterPage' }
            },
            {
                path: 'earnings',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./earnings/earnings.module */ 4149)).then(m => m.EarningsModule), data: { animation: 'FilterPage' }
            },
            {
                path: 'referrals',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./referral/referral.module */ 1293)).then(m => m.ReferralModule), data: { animation: 'HomePgae' }
            },
            {
                path: 'profile',
                loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./profile/profile.module */ 3602)).then(m => m.ProfileModule), data: { animation: 'AboutPage' }
            },
            {
                path: '',
                redirectTo: 'dashboard',
                pathMatch: 'full'
            }
        ]
    }
];
let MainRoutingModule = class MainRoutingModule {
};
MainRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], MainRoutingModule);



/***/ }),

/***/ 2284:
/*!****************************************!*\
  !*** ./src/app/main/main.component.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainComponent": () => (/* binding */ MainComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_main_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./main.component.html */ 4809);
/* harmony import */ var _main_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main.component.scss */ 8415);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/animation */ 3719);





let MainComponent = class MainComponent {
    constructor() { }
    ngOnInit() { }
    prepareRoute(outlet) {
        return outlet && outlet.activatedRouteData && outlet.activatedRouteData.animation;
    }
};
MainComponent.ctorParameters = () => [];
MainComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-main',
        template: _raw_loader_main_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        animations: [
            _services_animation__WEBPACK_IMPORTED_MODULE_2__.slideInAnimation
        ],
        styles: [_main_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MainComponent);



/***/ }),

/***/ 5705:
/*!*************************************!*\
  !*** ./src/app/main/main.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainModule": () => (/* binding */ MainModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _main_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-routing.module */ 9853);
/* harmony import */ var _dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard/dashboard.module */ 5929);
/* harmony import */ var _earnings_earnings_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./earnings/earnings.module */ 4149);
/* harmony import */ var _profile_profile_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile/profile.module */ 3602);
/* harmony import */ var _referral_referral_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./referral/referral.module */ 1293);
/* harmony import */ var _tasks_tasks_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tasks/tasks.module */ 4618);
/* harmony import */ var _main_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./main.component */ 2284);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../shared/shared.module */ 4466);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 476);












let MainModule = class MainModule {
};
MainModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        declarations: [_main_component__WEBPACK_IMPORTED_MODULE_6__.MainComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule,
            _main_routing_module__WEBPACK_IMPORTED_MODULE_0__.MainRoutingModule,
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__.SharedModule,
            _dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_1__.DashboardModule,
            _earnings_earnings_module__WEBPACK_IMPORTED_MODULE_2__.EarningsModule,
            _profile_profile_module__WEBPACK_IMPORTED_MODULE_3__.ProfileModule,
            _referral_referral_module__WEBPACK_IMPORTED_MODULE_4__.ReferralModule,
            _tasks_tasks_module__WEBPACK_IMPORTED_MODULE_5__.TasksModule
        ]
    })
], MainModule);



/***/ }),

/***/ 8377:
/*!********************************************************!*\
  !*** ./src/app/main/profile/profile-routing.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileRoutingModule": () => (/* binding */ ProfileRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _profile_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.component */ 1158);
/* harmony import */ var _profileedit_profileedit_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profileedit/profileedit.component */ 2971);
/* harmony import */ var _profileview_profileview_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profileview/profileview.component */ 7518);






const routes = [
    {
        path: '',
        component: _profile_component__WEBPACK_IMPORTED_MODULE_0__.ProfileComponent,
        children: [
            {
                path: '',
                component: _profileview_profileview_component__WEBPACK_IMPORTED_MODULE_2__.ProfileviewComponent,
            },
            {
                path: 'edit',
                component: _profileedit_profileedit_component__WEBPACK_IMPORTED_MODULE_1__.ProfileeditComponent,
            }
        ]
    }
];
let ProfileRoutingModule = class ProfileRoutingModule {
};
ProfileRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
    })
], ProfileRoutingModule);



/***/ }),

/***/ 1158:
/*!***************************************************!*\
  !*** ./src/app/main/profile/profile.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileComponent": () => (/* binding */ ProfileComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_profile_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profile.component.html */ 9312);
/* harmony import */ var _profile_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.component.scss */ 8602);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let ProfileComponent = class ProfileComponent {
    constructor() { }
    ngOnInit() { }
};
ProfileComponent.ctorParameters = () => [];
ProfileComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-profile',
        template: _raw_loader_profile_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profile_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProfileComponent);



/***/ }),

/***/ 3602:
/*!************************************************!*\
  !*** ./src/app/main/profile/profile.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileModule": () => (/* binding */ ProfileModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 8377);
/* harmony import */ var _profile_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.component */ 1158);
/* harmony import */ var _profileedit_profileedit_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profileedit/profileedit.component */ 2971);
/* harmony import */ var _profileview_profileview_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profileview/profileview.component */ 7518);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/shared.module */ 4466);









let ProfileModule = class ProfileModule {
};
ProfileModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [_profile_component__WEBPACK_IMPORTED_MODULE_1__.ProfileComponent, _profileview_profileview_component__WEBPACK_IMPORTED_MODULE_3__.ProfileviewComponent, _profileedit_profileedit_component__WEBPACK_IMPORTED_MODULE_2__.ProfileeditComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.SharedModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfileRoutingModule
        ]
    })
], ProfileModule);



/***/ }),

/***/ 2971:
/*!*******************************************************************!*\
  !*** ./src/app/main/profile/profileedit/profileedit.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileeditComponent": () => (/* binding */ ProfileeditComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_profileedit_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profileedit.component.html */ 9600);
/* harmony import */ var _profileedit_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profileedit.component.scss */ 2856);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let ProfileeditComponent = class ProfileeditComponent {
    constructor() { }
    ngOnInit() { }
};
ProfileeditComponent.ctorParameters = () => [];
ProfileeditComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-profileedit',
        template: _raw_loader_profileedit_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profileedit_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProfileeditComponent);



/***/ }),

/***/ 7518:
/*!*******************************************************************!*\
  !*** ./src/app/main/profile/profileview/profileview.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileviewComponent": () => (/* binding */ ProfileviewComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_profileview_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profileview.component.html */ 1220);
/* harmony import */ var _profileview_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profileview.component.scss */ 4560);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_loader_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/loader.service */ 8555);
/* harmony import */ var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/storage */ 8274);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 8939);









let ProfileviewComponent = class ProfileviewComponent {
    constructor(auth, loader, alertController, fireStore) {
        this.auth = auth;
        this.loader = loader;
        this.alertController = alertController;
        this.fireStore = fireStore;
        this.phoneVerified = false;
        this.emailVerified = false;
        this.defaultProfileImage = '../../../../assets/default-avatar.png';
        // profile image
        this.selectedFile = null;
    }
    ngOnInit() {
        this.auth.userData.asObservable().subscribe((userdata) => {
            if (userdata) {
                console.log(userdata);
                this.userData = userdata;
                this.emailVerified = userdata.emailVerified;
            }
        });
    }
    sendEmailVerification() {
        this.loader.showLoader().then(() => {
            this.auth.afAuth.currentUser.then(u => u.sendEmailVerification())
                .then(() => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
                const alert = yield this.alertController.create({
                    header: 'Email Verification',
                    // subHeader: 'Subtitle',
                    message: `Verification email has been sent your email (${this.userData.email}). Please check your inbox and verify your email.`,
                    buttons: [{ text: 'Ok' }]
                });
                yield alert.present();
                this.loader.stopLoader();
            }));
        });
    }
    showNameForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Change Name!',
                inputs: [
                    {
                        name: 'displayName',
                        type: 'text',
                        value: this.auth.userState && this.auth.userState.displayName ? this.auth.userState.displayName : '',
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary'
                    }, {
                        text: 'Ok',
                        handler: (d) => {
                            this.submitName(d);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    shoeDOBForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Choose Name!',
                inputs: [
                    {
                        name: 'dob',
                        type: 'date',
                        value: this.userData && this.userData.dob ? this.userData.dob : ''
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary'
                    }, {
                        text: 'Ok',
                        handler: (d) => {
                            this.submitMobile(d);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    showCityForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'City / State',
                inputs: [
                    {
                        name: 'city',
                        type: 'text',
                        value: this.userData && this.userData.city ? this.userData.city : '',
                        placeholder: 'City'
                    },
                    {
                        name: 'state',
                        type: 'text',
                        value: this.userData && this.userData.state ? this.userData.state : '',
                        placeholder: 'State'
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary'
                    }, {
                        text: 'Ok',
                        handler: (d) => {
                            this.submitCityState(d);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    submitName(data) {
        console.log(data);
        this.auth.updateProfile(data);
        // this.auth.updateAdditionalProfile(data);
    }
    submitMobile(data) {
        console.log(data);
        this.auth.updateProfile(data);
    }
    submitCityState(data) {
        console.log(data);
        this.auth.updateProfile(data);
    }
    // removeGoogle(){
    //   this.auth.unlinkSocial('google.com');
    // }
    onFileSelected(event) {
        this.loader.showLoader().then(() => {
            var n = Date.now();
            const file = event.target.files[0];
            console.log(file);
            const filePath = `profileImages/${this.auth.userUid}/${n}`;
            const fileRef = this.fireStore.ref(filePath);
            const task = this.fireStore.upload(`profileImages/${this.auth.userUid}/${n}`, file);
            task
                .snapshotChanges()
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.finalize)(() => {
                this.downloadURL = fileRef.getDownloadURL();
                this.downloadURL.subscribe(url => {
                    if (url) {
                        this.fb = url;
                        this.auth.afAuth.currentUser.then((u) => {
                            u.updateProfile({
                                photoURL: this.fb
                            }).then(() => {
                                this.auth.updateProfile({
                                    photoURL: this.fb
                                });
                                this.loader.stopLoader();
                            });
                        });
                        // this.auth.updateProfile({
                        //   photoURL: url
                        // }).then(()=>{
                        //   this.loader.stopLoader();
                        // })
                    }
                    console.log(this.fb);
                });
            }))
                .subscribe(url => {
                if (url.bytesTransferred === url.totalBytes && this.fb) {
                    console.log(url);
                    console.log(this.fb);
                }
            });
        });
    }
    showPasswordInput() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Change Password!',
                inputs: [
                    {
                        name: 'password',
                        type: 'text',
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary'
                    }, {
                        text: 'Ok',
                        handler: (d) => {
                            this.changePassword(d);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    changePassword(newPassword) {
        console.log(newPassword.password);
        this.loader.showLoader().then(() => {
            this.auth.afAuth.currentUser.then((user) => {
                user.updatePassword(newPassword.password).then(() => {
                    this.loader.stopLoader();
                }).catch(() => {
                    this.loader.stopLoader();
                });
            });
        });
    }
};
ProfileviewComponent.ctorParameters = () => [
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_loader_service__WEBPACK_IMPORTED_MODULE_3__.LoaderService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_fire_storage__WEBPACK_IMPORTED_MODULE_7__.AngularFireStorage }
];
ProfileviewComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-profileview',
        template: _raw_loader_profileview_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profileview_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProfileviewComponent);



/***/ }),

/***/ 642:
/*!**********************************************************!*\
  !*** ./src/app/main/referral/referral-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReferralRoutingModule": () => (/* binding */ ReferralRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _referral_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./referral.component */ 7613);




const routes = [
    {
        path: '',
        component: _referral_component__WEBPACK_IMPORTED_MODULE_0__.ReferralComponent
    }
];
let ReferralRoutingModule = class ReferralRoutingModule {
};
ReferralRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], ReferralRoutingModule);



/***/ }),

/***/ 7613:
/*!*****************************************************!*\
  !*** ./src/app/main/referral/referral.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReferralComponent": () => (/* binding */ ReferralComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_referral_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./referral.component.html */ 6146);
/* harmony import */ var _referral_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./referral.component.scss */ 5869);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/global-functions.service */ 4646);
/* harmony import */ var _capacitor_share__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/share */ 6380);
/* harmony import */ var _referralpopup_referralpopup_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./referralpopup/referralpopup.component */ 7046);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);









let ReferralComponent = class ReferralComponent {
    constructor(global, 
    // public actionSheetController: ActionSheetController,
    modalController, auth) {
        this.global = global;
        this.modalController = modalController;
        this.auth = auth;
        this.showShareModule = true;
        this.referListData = [
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
            {
                name: 'Ahtesham',
                points: 5,
                date: 'Mon, Jun 29 2021'
            },
        ];
        this.contentForTerms = 'Terms of service content.';
        this.contentForHowTo = 'How Invite system works content.';
    }
    ngOnInit() {
        this.auth.userData.asObservable().subscribe((user) => {
            this.currentUserData = user;
        });
    }
    refersChanged(event) {
        if (event.target.value == 'true') {
            this.showShareModule = true;
        }
        else {
            this.showShareModule = false;
        }
    }
    socialShare() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            console.log('social share clicked');
            const inviteCode = this.currentUserData && this.currentUserData.myInviteCode ? this.currentUserData.myInviteCode : "PL0011223344";
            yield _capacitor_share__WEBPACK_IMPORTED_MODULE_3__.Share.share({
                title: 'PayLo | रोज़ का रोज़गार',
                text: 'Create account on Paylo & get (रोज़ का रोज़गार), User my code for registration:- ' + inviteCode,
                url: 'http://google.com/',
                dialogTitle: 'Share & Get Rewards',
            }).then((response) => {
                console.log(response);
            }).catch((err) => {
                console.log(err);
            });
        });
    }
    presentTermsModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _referralpopup_referralpopup_component__WEBPACK_IMPORTED_MODULE_4__.ReferralpopupComponent,
                componentProps: {
                    'headerText': 'Terms of service.',
                    'htmlDataToParse': this.contentForTerms,
                }
            });
            return yield modal.present();
        });
    }
    presentHowToModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _referralpopup_referralpopup_component__WEBPACK_IMPORTED_MODULE_4__.ReferralpopupComponent,
                componentProps: {
                    'headerText': 'How it Works !',
                    'htmlDataToParse': this.contentForHowTo,
                }
            });
            return yield modal.present();
        });
    }
};
ReferralComponent.ctorParameters = () => [
    { type: src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_2__.GlobalFunctionsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_5__.AuthService }
];
ReferralComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-referral',
        template: _raw_loader_referral_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_referral_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ReferralComponent);



/***/ }),

/***/ 1293:
/*!**************************************************!*\
  !*** ./src/app/main/referral/referral.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReferralModule": () => (/* binding */ ReferralModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _referral_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./referral-routing.module */ 642);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ 4466);
/* harmony import */ var _referral_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./referral.component */ 7613);
/* harmony import */ var _referralpopup_referralpopup_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./referralpopup/referralpopup.component */ 7046);








let ReferralModule = class ReferralModule {
};
ReferralModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_referral_component__WEBPACK_IMPORTED_MODULE_2__.ReferralComponent, _referralpopup_referralpopup_component__WEBPACK_IMPORTED_MODULE_3__.ReferralpopupComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
            _referral_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReferralRoutingModule
        ]
    })
], ReferralModule);



/***/ }),

/***/ 7046:
/*!************************************************************************!*\
  !*** ./src/app/main/referral/referralpopup/referralpopup.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReferralpopupComponent": () => (/* binding */ ReferralpopupComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_referralpopup_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./referralpopup.component.html */ 473);
/* harmony import */ var _referralpopup_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./referralpopup.component.scss */ 4075);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);




let ReferralpopupComponent = class ReferralpopupComponent {
    constructor() { }
    ngOnInit() { }
};
ReferralpopupComponent.ctorParameters = () => [];
ReferralpopupComponent.propDecorators = {
    htmlDataToParse: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    headerText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
ReferralpopupComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-referralpopup',
        template: _raw_loader_referralpopup_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_referralpopup_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ReferralpopupComponent);



/***/ }),

/***/ 6199:
/*!*********************************************************!*\
  !*** ./src/app/main/tasks/mytasks/mytasks.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MytasksComponent": () => (/* binding */ MytasksComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_mytasks_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./mytasks.component.html */ 7325);
/* harmony import */ var _mytasks_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mytasks.component.scss */ 2450);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/global-functions.service */ 4646);





let MytasksComponent = class MytasksComponent {
    constructor(global) {
        this.global = global;
        this.today = new Date();
        this.segmentValue = "today";
        this.calendarOptions = {
            buttons: [{
                    text: 'Show Log',
                    handler: () => console.log('Clicked Save!')
                }, {
                    text: 'Cancel',
                    handler: () => {
                        console.log('Clicked Log. Do not Dismiss.');
                        this.segmentValue = "today";
                    }
                }]
        };
    }
    ngOnInit() { }
    openCalendar() {
        this.selectDate.open();
    }
};
MytasksComponent.ctorParameters = () => [
    { type: src_app_services_global_functions_service__WEBPACK_IMPORTED_MODULE_2__.GlobalFunctionsService }
];
MytasksComponent.propDecorators = {
    selectDate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: ['selectDate',] }]
};
MytasksComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-mytasks',
        template: _raw_loader_mytasks_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_mytasks_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MytasksComponent);



/***/ }),

/***/ 306:
/*!****************************************************!*\
  !*** ./src/app/main/tasks/tasks-routing.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksRoutingModule": () => (/* binding */ TasksRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _mytasks_mytasks_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mytasks/mytasks.component */ 6199);
/* harmony import */ var _tasks_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tasks.component */ 7551);





const routes = [
    {
        path: '',
        component: _tasks_component__WEBPACK_IMPORTED_MODULE_1__.TasksComponent,
        children: [
            {
                path: '',
                component: _mytasks_mytasks_component__WEBPACK_IMPORTED_MODULE_0__.MytasksComponent,
            }
        ]
    }
];
let TasksRoutingModule = class TasksRoutingModule {
};
TasksRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
    })
], TasksRoutingModule);



/***/ }),

/***/ 7551:
/*!***********************************************!*\
  !*** ./src/app/main/tasks/tasks.component.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksComponent": () => (/* binding */ TasksComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_tasks_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tasks.component.html */ 6161);
/* harmony import */ var _tasks_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tasks.component.scss */ 6101);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let TasksComponent = class TasksComponent {
    constructor() { }
    ngOnInit() { }
};
TasksComponent.ctorParameters = () => [];
TasksComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-tasks',
        template: _raw_loader_tasks_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tasks_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TasksComponent);



/***/ }),

/***/ 4618:
/*!********************************************!*\
  !*** ./src/app/main/tasks/tasks.module.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksModule": () => (/* binding */ TasksModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _tasks_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tasks-routing.module */ 306);
/* harmony import */ var _tasks_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tasks.component */ 7551);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 4466);
/* harmony import */ var _mytasks_mytasks_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mytasks/mytasks.component */ 6199);








let TasksModule = class TasksModule {
};
TasksModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_tasks_component__WEBPACK_IMPORTED_MODULE_1__.TasksComponent, _mytasks_mytasks_component__WEBPACK_IMPORTED_MODULE_3__.MytasksComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule,
            _tasks_routing_module__WEBPACK_IMPORTED_MODULE_0__.TasksRoutingModule
        ]
    })
], TasksModule);



/***/ }),

/***/ 8986:
/*!**********************************************!*\
  !*** ./src/app/services/taskview.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskviewService": () => (/* binding */ TaskviewService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _shared_taskview_taskview_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/taskview/taskview.component */ 5279);





let TaskviewService = class TaskviewService {
    constructor(modalController, alertController) {
        this.modalController = modalController;
        this.alertController = alertController;
        this.taskView = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.taskData = '';
    }
    toggleTaskView(taskId) {
        this.taskData = taskId;
        this.taskView.next(true);
    }
    get taskViewStatus() {
        return this.taskView.asObservable();
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _shared_taskview_taskview_component__WEBPACK_IMPORTED_MODULE_0__.TaskviewComponent,
                componentProps: {
                    'firstName': 'Douglas'
                },
                cssClass: 'showTaskPopup2',
                swipeToClose: true,
                mode: 'ios'
            });
            return yield modal.present();
        });
    }
    presentHelpModal(platform, task) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _shared_taskview_taskview_component__WEBPACK_IMPORTED_MODULE_0__.TaskviewComponent,
                componentProps: {
                    'firstName': 'Douglas'
                },
                cssClass: 'showTaskPopup',
                swipeToClose: true,
                mode: 'ios'
            });
            return yield modal.present();
        });
    }
    dismissModal() {
        this.modalController.dismiss();
    }
};
TaskviewService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController }
];
TaskviewService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], TaskviewService);



/***/ }),

/***/ 9470:
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_header_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./header.component.html */ 126);
/* harmony import */ var _header_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss */ 4783);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);





// import { AuthService } from 'src/app/services/auth.service';
let HeaderComponent = class HeaderComponent {
    constructor(auth) {
        this.auth = auth;
        this.verificationEmailIsSent = false;
        this.defaultAvatar = 'assets/default-avatar.png';
        this.userWallet = null;
    }
    ngOnInit() {
        this.auth.userData.asObservable().subscribe((userdata) => {
            if (userdata) {
                console.log(userdata);
                this.userData = userdata;
                this.auth.userWallet.asObservable().subscribe((wallet) => {
                    console.log(wallet);
                    this.userWallet = wallet;
                });
                // this.emailVerified = userdata.emailVerified;
            }
        });
    }
};
HeaderComponent.ctorParameters = () => [
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
HeaderComponent.propDecorators = {
    heading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input, args: ['heading',] }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-header',
        template: _raw_loader_header_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_header_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HeaderComponent);



/***/ }),

/***/ 4466:
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header/header.component */ 9470);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _taskview_taskview_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./taskview/taskview.component */ 5279);







let SharedModule = class SharedModule {
};
SharedModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent, _taskview_taskview_component__WEBPACK_IMPORTED_MODULE_1__.TaskviewComponent],
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule
        ],
        exports: [
            _header_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent,
            _taskview_taskview_component__WEBPACK_IMPORTED_MODULE_1__.TaskviewComponent
        ]
    })
], SharedModule);



/***/ }),

/***/ 5279:
/*!*******************************************************!*\
  !*** ./src/app/shared/taskview/taskview.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaskviewComponent": () => (/* binding */ TaskviewComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_taskview_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./taskview.component.html */ 1111);
/* harmony import */ var _taskview_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./taskview.component.scss */ 4821);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_services_taskview_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/taskview.service */ 8986);






let TaskviewComponent = class TaskviewComponent {
    constructor(taskService, actionSheetController, modalController) {
        this.taskService = taskService;
        this.actionSheetController = actionSheetController;
        this.modalController = modalController;
    }
    ngOnInit() {
        this.taskService.taskViewStatus.subscribe(result => {
            if (result) {
                const taskData = this.taskService.taskData;
                console.log(this.taskService.taskData);
                this.presentActionSheet(taskData);
            }
        });
    }
    presentActionSheet(taskId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            console.log(taskId);
            const actionSheet = yield this.actionSheetController.create({
                header: 'Albums',
                cssClass: 'my-custom-class',
                buttons: [{
                        text: 'Delete',
                        role: 'destructive',
                        icon: 'trash',
                        handler: () => {
                            console.log('Delete clicked');
                        }
                    }, {
                        text: 'Share',
                        icon: 'share',
                        handler: () => {
                            console.log('Share clicked');
                        }
                    }, {
                        text: 'Play (open modal)',
                        icon: 'caret-forward-circle',
                        handler: () => {
                            console.log('Play clicked');
                        }
                    }, {
                        text: 'Favorite',
                        icon: 'heart',
                        handler: () => {
                            console.log('Favorite clicked');
                        }
                    }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }]
            });
            yield actionSheet.present();
            const { role } = yield actionSheet.onDidDismiss();
            console.log('onDidDismiss resolved with role', role);
        });
    }
    dismissModal() {
        this.modalController.dismiss();
    }
};
TaskviewComponent.ctorParameters = () => [
    { type: src_app_services_taskview_service__WEBPACK_IMPORTED_MODULE_2__.TaskviewService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController }
];
TaskviewComponent.propDecorators = {
    firstName: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
TaskviewComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-taskview',
        template: _raw_loader_taskview_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_taskview_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TaskviewComponent);



/***/ }),

/***/ 6342:
/*!*********************************************************!*\
  !*** ./src/app/main/dashboard/dashboard.component.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXNoYm9hcmQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 6940:
/*!*******************************************************!*\
  !*** ./src/app/main/earnings/earnings.component.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".customInputItem2 {\n  border-radius: 64px;\n  --background: rgb(170 170 170 / 51%) ;\n}\n\ndiv#historyModule {\n  height: 80vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVhcm5pbmdzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQUE7RUFFQSxxQ0FBQTtBQUFGOztBQUtBO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FBRkYiLCJmaWxlIjoiZWFybmluZ3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tSW5wdXRJdGVtMiB7XG4gIGJvcmRlci1yYWRpdXM6IDY0cHg7XG4gIC8vIGJvcmRlci1yYWRpdXM6IHZhcigtLWJvcmRlci1yYWRpdXMpO1xuICAtLWJhY2tncm91bmQ6IHJnYigxNzAgMTcwIDE3MCAvIDUxJSlcbn1cbi8vIC5jdXN0b21JbnB1dEl0ZW0yIC5uYXRpdmUtaW5wdXQuc2MtaW9uLWlucHV0LWlvcyB7XG4vLyAgIHBhZGRpbmctbGVmdDogMjBweCAhaW1wb3J0YW50O1xuLy8gfVxuZGl2I2hpc3RvcnlNb2R1bGUge1xuICBoZWlnaHQ6IDgwdmg7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59Il19 */");

/***/ }),

/***/ 8415:
/*!******************************************!*\
  !*** ./src/app/main/main.component.scss ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWluLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 8602:
/*!*****************************************************!*\
  !*** ./src/app/main/profile/profile.component.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9maWxlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 2856:
/*!*********************************************************************!*\
  !*** ./src/app/main/profile/profileedit/profileedit.component.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9maWxlZWRpdC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 4560:
/*!*********************************************************************!*\
  !*** ./src/app/main/profile/profileview/profileview.component.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".userAvatarBig ion-icon {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n}\n\n.userAvatarBig div {\n  max-width: 200px;\n  max-height: 200px;\n  margin: 0 auto;\n  position: relative;\n}\n\n.userAvatarBig img {\n  width: 100%;\n  height: 100%;\n  border-radius: 15%;\n}\n\n#connectionsList ion-list-header,\n#connectionsList ion-item,\n#profileDetailsList ion-list-header,\n#profileDetailsList ion-item {\n  --padding-start: 0;\n  --padding-end: 0;\n  margin: 0;\n  padding: 0;\n}\n\n#profileDetailsList ion-item ion-text {\n  margin-right: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGV2aWV3LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUVGOztBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUdGOztBQUNBOzs7O0VBSUUsa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBRUY7O0FBQUE7RUFDRSwwQkFBQTtBQUdGIiwiZmlsZSI6InByb2ZpbGV2aWV3LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnVzZXJBdmF0YXJCaWcgaW9uLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMDtcbiAgcmlnaHQ6IDA7XG59XG4udXNlckF2YXRhckJpZyBkaXYge1xuICBtYXgtd2lkdGg6IDIwMHB4O1xuICBtYXgtaGVpZ2h0OiAyMDBweDtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi51c2VyQXZhdGFyQmlnIGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDE1JTtcbn1cbi8vICN2ZXJpZmljYXRpb25MaXN0IGlvbi1saXN0LWhlYWRlcixcbi8vICN2ZXJpZmljYXRpb25MaXN0IGlvbi1pdGVtLFxuI2Nvbm5lY3Rpb25zTGlzdCBpb24tbGlzdC1oZWFkZXIsXG4jY29ubmVjdGlvbnNMaXN0IGlvbi1pdGVtLFxuI3Byb2ZpbGVEZXRhaWxzTGlzdCBpb24tbGlzdC1oZWFkZXIsXG4jcHJvZmlsZURldGFpbHNMaXN0IGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAtLXBhZGRpbmctZW5kOiAwO1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG59XG4jcHJvZmlsZURldGFpbHNMaXN0IGlvbi1pdGVtIGlvbi10ZXh0IHtcbiAgbWFyZ2luLXJpZ2h0OiAwICFpbXBvcnRhbnQ7XG59XG4iXX0= */");

/***/ }),

/***/ 5869:
/*!*******************************************************!*\
  !*** ./src/app/main/referral/referral.component.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".sharingDiv {\n  background: #b94b4b;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZmVycmFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQUE7QUFDRiIsImZpbGUiOiJyZWZlcnJhbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zaGFyaW5nRGl2IHtcbiAgYmFja2dyb3VuZDogcmdiKDE4NSwgNzUsIDc1KTtcbn1cbiJdfQ== */");

/***/ }),

/***/ 4075:
/*!**************************************************************************!*\
  !*** ./src/app/main/referral/referralpopup/referralpopup.component.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWZlcnJhbHBvcHVwLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 2450:
/*!***********************************************************!*\
  !*** ./src/app/main/tasks/mytasks/mytasks.component.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJteXRhc2tzLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 6101:
/*!*************************************************!*\
  !*** ./src/app/main/tasks/tasks.component.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YXNrcy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 4783:
/*!*****************************************************!*\
  !*** ./src/app/shared/header/header.component.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#userProfile {\n  float: left;\n}\n\n#userMenu {\n  float: right;\n}\n\n#customHeader {\n  display: block;\n}\n\n#userAvatar {\n  display: inline-block;\n}\n\n#userAvatar img {\n  border-radius: 10px;\n  box-shadow: -4px -2px 18px 0px rgba(0, 0, 0, 0.2);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFRQTtFQUNFLFdBQUE7QUFQRjs7QUFTQTtFQUNFLFlBQUE7QUFORjs7QUFRQTtFQUNFLGNBQUE7QUFMRjs7QUFPQTtFQUVFLHFCQUFBO0FBTEY7O0FBT0E7RUFDRSxtQkFBQTtFQUNBLGlEQUFBO0FBSkYiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gLmN1c3RvbUhlYWRlciB7XG4vLyAgIHBvc2l0aW9uOiBmaXhlZDtcbi8vICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuLy8gfVxuLy8gLmhlYWRlclBhcnQge1xuLy8gIG1heC13aWR0aDogNTAlO1xuLy8gfVxuI3VzZXJQcm9maWxlIHtcbiAgZmxvYXQ6IGxlZnQ7XG59XG4jdXNlck1lbnUge1xuICBmbG9hdDogcmlnaHQ7XG59XG4jY3VzdG9tSGVhZGVyIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4jdXNlckF2YXRhciB7XG4gIC8vIGRpc3BsYXk6IGJsb2NrO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG4jdXNlckF2YXRhciBpbWcge1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBib3gtc2hhZG93OiAtNHB4IC0ycHggMThweCAwcHggcmdiKDAgMCAwIC8gMjAlKTtcbn1cbiJdfQ== */");

/***/ }),

/***/ 4821:
/*!*********************************************************!*\
  !*** ./src/app/shared/taskview/taskview.component.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YXNrdmlldy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ 1295:
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/dashboard/dashboard.component.html ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content class=\"ion-padding\">\n\n  <app-header></app-header>\n\n  <ion-card id=\"statsBar\" #weeklyTasksUpdate>\n    <ion-row>\n      <ion-col size=\"5\">\n        <ngx-circular-progress [value]=\"weeklyTasksPercentage\" [color]=\"'#3880ff'\" [txtColor]=\"'#3880ff'\"></ngx-circular-progress>\n      </ion-col>\n      <ion-col size=\"7\">\n        <div class=\"verticalCenter\">\n          <ion-text>\n            <h3>Weekly Progress</h3>\n          </ion-text>\n          <ion-text color=\"primary\"><b>{{weeklyTasksCompleted}}/{{weeklyTasksTotal}}</b> completed tasks</ion-text>\n          <ion-card-subtitle></ion-card-subtitle>\n        </div>\n      </ion-col>\n      <ion-icon size=\"lg\" name=\"bar-chart-outline\"></ion-icon>\n    </ion-row>\n  </ion-card>\n\n  <ion-item button lines=\"none\" detail=\"false\">\n    <ion-label>\n      <b>You have 5 tasks for today</b>\n    </ion-label>\n    <ion-icon name=\"calendar-outline\" slot=\"end\"></ion-icon>\n  </ion-item>\n\n  <div class=\"dashTasksList\">\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard facebookBg\" (click)=\"taskService.presentModal()\">\n        <ion-card-content>\n          <ion-text>\n            <h2>Facebook Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Like, Comment, Share</b> <br />(inProgress)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard youtubeBg\" (click)=\"taskService.presentModal()\">\n        <ion-card-content>\n          <ion-text>\n            <h2>YouTube Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Like, Comment</b> <br />(inProgress)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard instagramBg\" (click)=\"taskService.presentModal()\">\n        <ion-card-content>\n          <ion-text>\n            <h2>Instagram Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Like, Follow</b> <br />(waiting)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard twitterBg\" (click)=\"taskService.presentModal()\">\n        <ion-card-content>\n          <ion-text>\n            <h2>Twitter Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Re-Tweet</b> <br />(waiting)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 6410:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/earnings/earnings.component.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content class=\"ion-padding\">\n  <div class=\"ion-padding-top\">\n    <ion-segment (ionChange)=\"modulePageChange($event)\" [value]='showModule'>\n      <ion-segment-button value=\"wallet\">\n        <ion-label>Wallet</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"conversions\">\n        <ion-label>Conversions</ion-label>\n      </ion-segment-button>\n      <!-- <ion-segment-button value=\"history\">\n        <ion-label>History</ion-label>\n      </ion-segment-button> -->\n    </ion-segment>\n  </div>\n  <div id=\"walletModule\" *ngIf=\"showModule === 'wallet'\">\n    <!-- Main Card -->\n    <ion-card class=\"ion-margin-top ion-no-margin\">\n      <ion-card-header>\n        <ion-card-subtitle>Your current/total points</ion-card-subtitle>\n        <ion-card-title>{{myWallet.currentPoints}}/<small>{{myWallet.totalPoints}}&nbsp;&nbsp;</small> <span\n            [innerHtml]=\"global.sign\"></span></ion-card-title>\n      </ion-card-header>\n      <ion-card-header>\n        <ion-card-subtitle>Your converted points to rupees</ion-card-subtitle>\n        <ion-card-title><small>{{myWallet.totalConvertedPoints}}&nbsp;&nbsp;<span [innerHtml]=\"global.sign\"></span> /\n            {{myWallet.totalConvertedAmount}}&nbsp;&nbsp;&#8377;</small></ion-card-title>\n      </ion-card-header>\n\n      <ion-card-content>\n        When converting you need minimum 60 <span [innerHtml]=\"global.sign\"></span> have in the wallet.<br />\n        Minimum converted points will be 50 <span [innerHtml]=\"global.sign\"></span><br /><br />\n        <span *ngIf=\"myWallet.userUpi\" (click)=\"showUpiForm = true\">\n          Your Upi Id is:-<br />\n          {{myWallet.userUpi}}\n          <span style=\"float: right;\">\n            <ion-icon name=\"create-outline\"></ion-icon>\n          </span>\n        </span>\n      </ion-card-content>\n    </ion-card>\n\n    <!-- UPI Form -->\n    <ion-card class=\"ion-margin-top ion-no-margin\" *ngIf=\"!myWallet.userUpi || showUpiForm\">\n      <ion-card-header>\n        <ion-card-subtitle>Add UPI</ion-card-subtitle>\n        <ion-card-subtitle>For converting the points you need to be have an UPI ID</ion-card-subtitle>\n      </ion-card-header>\n      <ion-card-content [formGroup]=\"upiForm\" (ngSubmit)=\"saveUpiId()\">\n        <ion-item class=\"customInputItem2\">\n          <!-- <ion-icon><span [innerHtml]=\"global.sign\"></span></ion-icon> -->\n          <!-- <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\" *ngIf=\"loginForm.controls.email.valid\"></ion-icon> -->\n          <!-- <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\" *ngIf=\"loginForm.controls.email.invalid && (loginForm.controls.email.dirty || loginForm.controls.email.touched)\"></ion-icon> -->\n          <ion-input formControlName=\"userUpi\" type=\"text\" placeholder=\"ex: upi@bank\"></ion-input>\n        </ion-item>\n        <ion-button type=\"submit\" (click)=\"saveUpiId()\" shape=\"round\" class=\"shadow ion-margin-top\" color=\"secondary\"\n          expand=\"block\">Save UPI</ion-button>\n        <ion-button type=\"button\" (click)=\"showUpiForm = false\" shape=\"round\" class=\"shadow ion-margin-top\"\n          color=\"danger\" expand=\"block\" *ngIf=\"myWallet.userUpi && showUpiForm\">Cancel</ion-button>\n      </ion-card-content>\n    </ion-card>\n\n    <!-- Points Withdrawl Form -->\n    <ion-card class=\"ion-margin-top ion-no-margin\"\n      *ngIf=\"myWallet.userUpi && myWallet.currentPoints >= 60 && !showUpiForm\">\n      <ion-card-header>\n        <ion-card-subtitle>Convert your points</ion-card-subtitle>\n      </ion-card-header>\n      <ion-card-content [formGroup]=\"walletForm\" (ngSubmit)=\"createWithdrawlRequest()\">\n        <ion-item class=\"customInputItem2\">\n          <!-- <ion-icon><span [innerHtml]=\"global.sign\"></span></ion-icon> -->\n          <!-- <ion-icon color=\"success\" slot=\"end\" name=\"checkmark-done-circle-outline\" *ngIf=\"loginForm.controls.email.valid\"></ion-icon> -->\n          <!-- <ion-icon color=\"danger\" slot=\"end\" name=\"close-circle-outline\" *ngIf=\"loginForm.controls.email.invalid && (loginForm.controls.email.dirty || loginForm.controls.email.touched)\"></ion-icon> -->\n          <ion-input formControlName=\"points\" value=\"50\" type=\"number\" min=\"50\"></ion-input>\n        </ion-item>\n        <ion-label><b>Convert into:-</b> {{walletForm.controls.amount.value}} &#8377;</ion-label>\n        <ion-button (click)=\"createWithdrawlRequest()\" type=\"submit\" shape=\"round\" class=\"shadow ion-margin-top\"\n          color=\"secondary\" expand=\"block\">Convert & Request</ion-button>\n      </ion-card-content>\n    </ion-card>\n\n    <!-- Less Points Notice -->\n    <ion-card class=\"ion-margin-top ion-no-margin\" *ngIf=\"myWallet.currentPoints < 60\">\n      <ion-card-content>\n        <ion-text color=\"danger\">\n          You dont have enough points to convert, please earn minimum 60 points to make 50 point conversion.\n        </ion-text>\n      </ion-card-content>\n    </ion-card>\n  </div>\n  <div id=\"convertionsModule\" *ngIf=\"showModule === 'conversions'\">\n    <div class=\"ion-padding-top ion-margin-bottom\">\n      <div *ngIf=\"convertionWithdrawls && convertionWithdrawls.length > 0; else noConversions\">\n        <ion-virtual-scroll [items]=\"convertionWithdrawls\" approxItemHeight=\"320px\">\n          <ion-item *virtualItem=\"let item; let i = index\" id=\"{{i}}\"\n            (click)=\"showAlertForConvertion(item.id)\">\n            <ion-label>{{item.points}} <span [innerHtml]=\"global.sign\"></span> to {{item.amount}} &#8377;\n              <br /><small>@ {{item.timeCreated | date:\"medium\"}}</small>\n              <br /><small>@ UPI:- {{item.upi_id}}</small>\n            </ion-label>\n            <ion-badge slot=\"end\" color=\"primary\"\n              *ngIf=\"item.isRequested && !item.isCompleted && !item.isRejected && !item.isOnHold\">In Process</ion-badge>\n            <ion-badge slot=\"end\" color=\"success\"\n              *ngIf=\"item.isRequested && item.isCompleted && !item.isRejected && !item.isOnHold\">Completed</ion-badge>\n            <ion-badge slot=\"end\" color=\"danger\"\n              *ngIf=\"item.isRequested && !item.isCompleted && item.isRejected && !item.isOnHold\">Rejected</ion-badge>\n            <ion-badge slot=\"end\" color=\"warning\"\n              *ngIf=\"item.isRequested && !item.isCompleted && !item.isRejected && item.isOnHold\">On-Hold</ion-badge>\n          </ion-item>\n        </ion-virtual-scroll>\n      </div>\n      <ng-template #noConversions>\n        You dont have any conversions yet\n      </ng-template>\n    </div>\n  </div>\n  <div id=\"historyModule\" *ngIf=\"showModule === 'history'\">\n    <div class=\"ion-padding-top ion-margin-bottom\">\n      <ion-list *ngIf=\"pointsHistory && pointsHistory.length > 0\">\n        <ion-item *ngFor=\"let point of pointsHistory; let i = index\" id=\"{{i}}\" id=\"{{i}}\">\n          <ion-label> {{point.taskId ? 'Task' : 'Invited User'}}</ion-label>\n          <ion-text slot=\"end\">{{point.points}} <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n        <!-- <ion-item>\n          <ion-label> Facebook <small><b>Task</b></small><br /><small>Like, Comment, Share</small><br /><small>Mon, Jun\n              29 2021</small></ion-label>\n          <ion-text slot=\"end\">15 <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>Ahtesham<br /><small>Mon, Jun 29 2021</small></ion-label>\n          <ion-text slot=\"end\">5 <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>Ahtesham<br /><small>Mon, Jun 29 2021</small></ion-label>\n          <ion-text slot=\"end\">5 <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>Ahtesham<br /><small>Mon, Jun 29 2021</small></ion-label>\n          <ion-text slot=\"end\">5 <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>Ahtesham<br /><small>Mon, Jun 29 2021</small></ion-label>\n          <ion-text slot=\"end\">5 <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>Ahtesham<br /><small>Mon, Jun 29 2021</small></ion-label>\n          <ion-text slot=\"end\">5 <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item> -->\n      </ion-list>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ 4809:
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/main.component.html ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!-- <ion-router-outlet></ion-router-outlet> -->\n\n<div [@routeAnimations]=\"prepareRoute(outlet)\">\n  <ion-router-outlet #outlet=\"outlet\"></ion-router-outlet>\n</div>\n<ion-tabs id=\"customTabBar\">\n  <!-- <app-taskview></app-taskview> -->\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"dashboard\">\n      <ion-icon size=\"small\" name=\"home-outline\"></ion-icon>\n    </ion-tab-button>\n\n    <!-- <ion-tab-button tab=\"tasks\">\n      <ion-icon size=\"small\" name=\"document-text-outline\"></ion-icon>\n    </ion-tab-button> -->\n\n    <ion-tab-button tab=\"earnings\">\n      <ion-icon size=\"small\" name=\"diamond-outline\"></ion-icon>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"referrals\">\n      <ion-icon size=\"small\" name=\"ticket-outline\"></ion-icon>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"profile\">\n      <ion-icon size=\"small\" name=\"person-outline\"></ion-icon>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>\n");

/***/ }),

/***/ 9312:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/profile/profile.component.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-router-outlet></ion-router-outlet>\n");

/***/ }),

/***/ 9600:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/profile/profileedit/profileedit.component.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<p>\n  profileedit works!\n</p>\n");

/***/ }),

/***/ 1220:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/profile/profileview/profileview.component.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content class=\"ion-padding\">\n  <!-- <app-header></app-header> -->\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button (click)=\"auth.signOut()\">\n      <ion-icon name=\"log-out-outline\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <ion-row>\n    <ion-col size-sm=\"6\" size=\"12\" style=\"text-align: center;\" class=\"userAvatarBig\">\n      <div>\n        <input type=\"file\" hidden name=\"profieImage\" #userPhoto (change)=\"onFileSelected($event)\">\n        <ion-icon name=\"create\" size=\"large\" color=\"primary\" (click)=\"userPhoto.click()\"></ion-icon>\n        <img [src]=\"userData && userData.photoURL ? userData.photoURL : defaultProfileImage\">\n      </div>\n    </ion-col>\n    <ion-col size-sm=\"6\" size=\"12\">\n      <ion-list id=\"profileDetailsList\">\n        <ion-list-header lines=\"inset\">\n          <ion-label>Details</ion-label>\n        </ion-list-header>\n        <ion-item>\n          <ion-label>\n            {{userData && userData.displayName ? userData.displayName : ''}}\n          </ion-label>\n          <ion-text slot=\"end\" (click)=\"showNameForm()\">\n            <ion-icon name=\"create-outline\" size=\"large\" color=\"primary\"></ion-icon>\n          </ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>\n            {{userData && userData.phoneNumber ? userData.phoneNumber : 'Your Phone Number'}}<br />\n            <!-- <ion-badge color=\"danger\" *ngIf=\"!phoneVerified\">Not Verified</ion-badge>\n            <ion-badge color=\"success\" *ngIf=\"phoneVerified\">Verified</ion-badge> -->\n          </ion-label>\n          <!-- <ion-text slot=\"end\">\n            <ion-icon name=\"chevron-forward-circle-outline\" size=\"large\" color=\"danger\" *ngIf=\"!phoneVerified\">\n            </ion-icon>\n            <ion-icon name=\"checkmark-done-circle-outline\" size=\"large\" color=\"success\" *ngIf=\"phoneVerified\">\n            </ion-icon>\n          </ion-text> -->\n        </ion-item>\n        <ion-item>\n          <ion-label>\n            {{userData && userData.email ? userData.email : ''}}<br />\n            <ion-badge color=\"danger\" *ngIf=\"!emailVerified\">Not Verified</ion-badge>\n            <ion-badge color=\"success\" *ngIf=\"emailVerified\">Verified</ion-badge>\n          </ion-label>\n          <ion-text slot=\"end\">\n            <ion-button color=\"danger\" *ngIf=\"!emailVerified\" (click)=\"sendEmailVerification()\">\n              Verify\n            </ion-button>\n            <ion-icon name=\"checkmark-done-circle-outline\" size=\"large\" color=\"success\" *ngIf=\"emailVerified\">\n            </ion-icon>\n          </ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>{{userData && userData.dob ? (userData.dob | date:\"mediumDate\") : 'Add Date of Birth'}}</ion-label>\n          <ion-text slot=\"end\" (click)=\"shoeDOBForm()\">\n            <ion-icon name=\"create-outline\" size=\"large\" color=\"primary\"></ion-icon>\n          </ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>{{userData && userData.city ? userData.city : 'City'}} / {{userData && userData.state ?\n            userData.state : 'State'}}</ion-label>\n          <ion-text slot=\"end\" (click)=\"showCityForm()\">\n            <ion-icon name=\"create-outline\" size=\"large\" color=\"primary\"></ion-icon>\n          </ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-text color=\"primary\" (click)=\"showPasswordInput()\">\n            Change Password\n          </ion-text>\n        </ion-item>\n      </ion-list>\n      <ion-list id=\"connectionsList\">\n        <ion-list-header lines=\"inset\">\n          <ion-label>Connections</ion-label>\n        </ion-list-header>\n        <ion-item>\n          <ion-label>Facebook</ion-label>\n          <ion-text slot=\"end\">\n            <ion-icon name=\"chevron-forward-circle-outline\" size=\"large\" color=\"danger\" (click)=\"auth.linkFacebook()\" *ngIf=\"!auth.facebookConnected\">\n            </ion-icon>\n            <ion-icon name=\"checkmark-done-circle-outline\" size=\"large\" color=\"success\" *ngIf=\"auth.facebookConnected\">\n            </ion-icon>\n          </ion-text>\n        </ion-item>\n        <ion-item>\n          <ion-label>Google</ion-label>\n          <ion-text slot=\"end\">\n            <ion-icon name=\"chevron-forward-circle-outline\" size=\"large\" color=\"danger\" (click)=\"auth.linkGoogle()\" *ngIf=\"!auth.googleConnected\">\n            </ion-icon>\n            <ion-icon name=\"checkmark-done-circle-outline\" size=\"large\" color=\"success\" *ngIf=\"auth.googleConnected\">\n            </ion-icon>\n          </ion-text>\n        </ion-item>\n      </ion-list>\n    </ion-col>\n  </ion-row>\n</ion-content>\n");

/***/ }),

/***/ 6146:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/referral/referral.component.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content class=\"ion-padding\">\n  <!-- <div class=\"ion-padding-top\">\n    <ion-segment (ionChange)=\"refersChanged($event)\" [value]='showShareModule'>\n      <ion-segment-button [value]=true>\n        <ion-label>Share to Earn</ion-label>\n      </ion-segment-button>\n      <ion-segment-button [value]=false>\n        <ion-label>Invited List</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n  </div> -->\n  <div id=\"shareModule\" *ngIf=\"showShareModule\">\n    <div class=\"ion-padding-top ion-margin-bottom\">\n      <ion-item lines=\"none\">\n        <ion-label>Total invited users: <ion-text style=\"float: right;\">15</ion-text>\n        </ion-label>\n      </ion-item>\n    </div>\n    <ion-card class=\"ion-padding-bottom ion-no-margin ion-text-center\">\n      <div>\n        <img src=\"../../../assets/sharing.png\" style=\"width:230px;margin:auto;\" />\n        <ion-text>\n          <h3>share to get points</h3>\n          <p class=\"ion-padding\">\n            You invite your friends & they register with your invite code. Every registration gets you 5* points.<br/>\n            Invite Code:- <b>{{currentUserData && currentUserData.myInviteCode ? currentUserData.myInviteCode : \"PL0011223344\"}}</b>\n          </p>\n        </ion-text>\n        <ion-button color=\"primary\" (click)=\"socialShare()\"> Share Here <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n        </ion-button>\n      </div>\n    </ion-card>\n    <div class=\"ion-padding-top\">\n      <ion-item lines=\"none\" (click)=\"presentHowToModal()\">\n        <ion-text color=\"primary\">How invite system works?</ion-text>\n      </ion-item>\n      <ion-item lines=\"none\" (click)=\"presentTermsModal()\">\n        <ion-text color=\"primary\">Terms of service</ion-text>\n      </ion-item>\n    </div>\n  </div>\n  <!-- <div id=\"inviteListModule\" *ngIf=\"!showShareModule\">\n    <div class=\"ion-padding-top ion-margin-bottom\">\n      <ion-virtual-scroll [items]=\"referListData\" approxItemHeight=\"320px\">\n        <ion-item lines=\"none\"*virtualItem=\"let item; let itemBounds = bounds;\">\n          <ion-label>{{item.name}}<br/><small>{{item.date}}</small></ion-label>\n          <ion-text slot=\"end\">{{item.points}} <span [innerHtml]=\"global.sign\"></span></ion-text>\n        </ion-item>\n      </ion-virtual-scroll>\n    </div>\n  </div> -->\n</ion-content>\n");

/***/ }),

/***/ 473:
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/referral/referralpopup/referralpopup.component.html ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header translucent>\n  <ion-toolbar>\n    <ion-title>{{headerText}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button onclick=\"dismissModal()\">Close</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content fullscreen>\n  <div [innerHtml]=\"htmlDataToParse\"></div>\n</ion-content>");

/***/ }),

/***/ 7325:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/tasks/mytasks/mytasks.component.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content class=\"ion-padding\">\n  <app-header></app-header>\n  <!-- <div>\n    <ion-segment [value]=\"segmentValue\" color=\"secondary\">\n      <ion-segment-button value=\"today\">\n        <ion-label>Today</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"yesterday\">\n        <ion-label>Yesterday</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"{{today}}\" (click)=\"openCalendar()\">\n        <ion-datetime [pickerOptions]=\"calendarOptions\" #selectDate displayFormat=\"MMM D, YYYY\" value=\"{{today}}\" display-timezone=\"utc\"></ion-datetime>\n      </ion-segment-button>\n    </ion-segment>\n  </div> -->\n  <div class=\"ion-padding-top\">\n    <ion-item>\n      <ion-label position=\"fixed\">Tasks List:</ion-label>\n      <ion-datetime [pickerOptions]=\"calendarOptions\" #selectDate displayFormat=\"MMM D, YYYY\" value=\"{{today}}\" display-timezone=\"utc\"></ion-datetime>\n    </ion-item>\n  </div>\n  <div class=\"dashTasksList\">\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard facebookBg\">\n        <ion-card-content>\n          <ion-text>\n            <h2>Facebook Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Like, Comment, Share</b> <br />(inProgress)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard youtubeBg\">\n        <ion-card-content>\n          <ion-text>\n            <h2>YouTube Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Like, Comment</b> <br />(inProgress)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard instagramBg\">\n        <ion-card-content>\n          <ion-text>\n            <h2>Instagram Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Like, Follow</b> <br />(waiting)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div class=\"task\">\n      <ion-card class=\"flexCard twitterBg\">\n        <ion-card-content>\n          <ion-text>\n            <h2>Twitter Task <b>(15 <span [innerHtml]=\"global.sign\"></span>)</b></h2>\n            <b>Re-Tweet</b> <br />(waiting)\n          </ion-text>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ 6161:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main/tasks/tasks.component.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-router-outlet></ion-router-outlet>\n");

/***/ }),

/***/ 126:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header/header.component.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!-- <ion-item lines=\"none\" style=\"--padding-start: 0; --padding-end: 0;\"> -->\n  <ion-thumbnail id=\"userAvatar\" [routerLink]=\"['/main/profile']\">\n    <!-- <span class=\"notifyIcon\"></span> -->\n    <img [src]=\"userData && userData.photoURL ? userData.photoURL : defaultAvatar\">\n  </ion-thumbnail>\n  <ion-label style=\"text-align: right;  float: right;\">\n    <h3>Welcome {{userData && userData.displayName ? userData.displayName : userData ? userData.uid : ''}}</h3>\n    <p>Total points: &#x20B1;&#x2C60; {{userWallet && userWallet.currentPoints ? userWallet.currentPoints : 0}}</p>\n  </ion-label>\n<!-- </ion-item> -->\n<!-- <ion-thumbnail id=\"userAvatar\">\n  <span class=\"notifyIcon\"></span>\n  <img src=\"assets/default-avatar.png\">\n</ion-thumbnail> -->\n");

/***/ }),

/***/ 1111:
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/taskview/taskview.component.html ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!-- <ion-header> -->\n<!-- <ion-toolbar> -->\n<!-- <ion-title>{{firstName}}</ion-title> -->\n<!-- <ion-buttons slot=\"end\" class=\"text-right\" style=\"display: block;\">\n  <ion-button color=\"dark\" fill=\"clear\" style=\"float: right;\" size=\"large\" (click)=\"dismissModal()\">\n    <ion-icon name=\"close-outline\"></ion-icon>\n  </ion-button>\n</ion-buttons> -->\n<!-- </ion-toolbar> -->\n<!-- </ion-header> -->\n<!-- <ion-buttons> -->\n  <ion-button expand=\"block\" color=\"primary\" shape=\"round\">Start Task</ion-button>\n  <ion-button expand=\"block\" color=\"tertiary\" shape=\"round\" (click)=\"taskService.presentHelpModal('facebook', 'like')\">How to !</ion-button>\n  <ion-button expand=\"block\" color=\"danger\" shape=\"round\" (click)=\"dismissModal()\">Close</ion-button>\n<!-- </ion-buttons> -->");

/***/ })

}]);
//# sourceMappingURL=src_app_main_main_module_ts.js.map