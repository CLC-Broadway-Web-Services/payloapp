(self["webpackChunkpaylo"] = self["webpackChunkpaylo"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/fire/auth-guard */ 8386);




const redirectUnauthorizedToLogin = () => (0,_angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_0__.redirectUnauthorizedTo)(['auth']);
const redirectLoggedInToDashboard = () => (0,_angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_0__.redirectLoggedInTo)(['main']);
const routes = [
    {
        path: 'auth',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_capacitor_core_dist_index_js-src_app_services_global-functions_service_ts"), __webpack_require__.e("src_app_auth_auth_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./auth/auth.module */ 1674)).then(m => m.AuthModule),
        canActivate: [_angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AngularFireAuthGuard], data: { authGuardPipe: redirectLoggedInToDashboard }
    },
    {
        path: 'main',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_capacitor_core_dist_index_js-src_app_services_global-functions_service_ts"), __webpack_require__.e("src_app_main_main_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./main/main.module */ 5705)).then(m => m.MainModule),
        canActivate: [_angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }
    },
    {
        path: '',
        redirectTo: 'auth',
        pathMatch: 'full'
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.NoPreloading })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 1106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 3069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _services_animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/animation */ 3719);





// import { Plugins } from '@capacitor/core';
// eslint-disable-next-line @typescript-eslint/naming-convention
// const { App } = Plugins;
// import { Device } from '@ionic-native/device/ngx';
// import { BackgroundMode } from '@ionic-native/background-mode/ngx';
// import { Autostart } from '@ionic-native/autostart/ngx';

let AppComponent = class AppComponent {
    constructor(
    // private device: Device,
    // private backgroundMode: BackgroundMode,
    // private autostart: Autostart,
    // private androidPermissions: AndroidPermissions,
    platform) {
        this.platform = platform;
        console.log(this.platform.platforms());
        if (this.platform.platforms().includes('android')) {
            // console.log('this is android')
            // console.log('Device UUID is: ' + this.device.uuid);
            // this.backgroundMode.enable();
            // this.autostart.enable();
            // this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.CAMERA).then(
            //   result => console.log('Has permission?',result.hasPermission),
            //   err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.CAMERA)
            // );
            // this.androidPermissions.requestPermissions([this.androidPermissions.PERMISSION.CAMERA, this.androidPermissions.PERMISSION.GET_ACCOUNTS]);
            // this.platform.backButton.subscribeWithPriority(-1, () => {
            //   if (!this.routerOutlet.canGoBack()) {
            //     App.exitApp();
            //   }
            // });
        }
    }
    prepareRoute(outlet) {
        return outlet && outlet.activatedRouteData && outlet.activatedRouteData.animation;
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.Platform }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        animations: [
            _services_animation__WEBPACK_IMPORTED_MODULE_2__.slideInAnimation
        ],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser/animations */ 5835);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/fire */ 57);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/auth.service */ 7556);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ 4276);
/* harmony import */ var _angular_fire_functions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/fire/functions */ 9486);















// import { Device } from '@ionic-native/device/ngx';
// import { Autostart } from '@ionic-native/autostart/ngx';
// import { BackgroundMode } from '@ionic-native/background-mode/ngx';
// import { Firebase } from '@ionic-native/firebase/ngx';

// import { USE_EMULATOR as USE_FUNCTIONS_EMULATOR } from '@angular/fire/functions';
// import firebase from 'firebase/app';
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__.BrowserAnimationsModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule.forRoot({
                mode: 'ios',
                swipeBackEnabled: true,
                sanitizerEnabled: true,
                hardwareBackButton: true
            }),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _angular_fire__WEBPACK_IMPORTED_MODULE_11__.AngularFireModule.initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.firebaseConfig),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_12__.AngularFireAuthModule,
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_13__.AngularFirestoreModule,
            _angular_fire_functions__WEBPACK_IMPORTED_MODULE_14__.AngularFireFunctionsModule
        ],
        providers: [
            { provide: _angular_fire_functions__WEBPACK_IMPORTED_MODULE_14__.REGION, useValue: 'asia-south1' },
            // { provide: USE_FUNCTIONS_EMULATOR, useValue: environment.useEmulators ? ['localhost', 5001] : undefined },
            //  { provide: NEW_ORIGIN_BEHAVIOR, useValue: true },
            //  { provide: ORIGIN, useValue: 'http://localhost:5000/' },
            _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService,
            _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_4__.SocialSharing,
            // Device,
            // BackgroundMode,
            // Autostart,
            // Firebase,
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicRouteStrategy }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 3992:
/*!*************************************!*\
  !*** ./src/app/interfaces/tasks.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Task": () => (/* binding */ Task)
/* harmony export */ });
class Task {
    constructor() {
        this.approvedBy = '';
        this.campaignId = '';
        this.inProgress = false;
        this.isAlloted = true;
        this.isApproved = false;
        this.isRejected = false;
        this.isSubmitted = false;
        this.isExpired = false;
        this.platform = '';
        this.proof = '';
        this.rejectReason = '';
        this.rejectedBy = '';
        this.uid = '';
        this.url = '';
        this.allotedDateNum = Date.now();
        this.allotedDate = '';
        this.approvedDate = 0;
    }
}


/***/ }),

/***/ 6845:
/*!**************************************!*\
  !*** ./src/app/interfaces/wallet.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wallet": () => (/* binding */ Wallet)
/* harmony export */ });
class Wallet {
    constructor() {
        this.id = '';
        this.totalPoints = 0;
        this.currentPoints = 0;
        this.totalConvertedPoints = 0;
        this.convertionRateInitial = 1;
        this.totalConvertedAmount = 0;
        this.withdrawlAmount = 0;
        this.userUpi = '';
        this.uid = '';
    }
}


/***/ }),

/***/ 3719:
/*!***************************************!*\
  !*** ./src/app/services/animation.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "slideInAnimation": () => (/* binding */ slideInAnimation)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/animations */ 7238);

const slideInAnimation = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)('routeAnimations', [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('HomePage <=> AboutPage', [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ position: 'relative' }),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter, :leave', [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%'
            })
        ]),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter', [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ left: '-100%' })
        ]),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animateChild)()),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.group)([
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':leave', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('300ms ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ left: '100%' }))
            ]),
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('300ms ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ left: '0%' }))
            ])
        ]),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animateChild)()),
    ]),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)('* <=> FilterPage', [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ position: 'relative' }),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter, :leave', [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%'
            })
        ]),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter', [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ left: '-100%' })
        ]),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animateChild)()),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.group)([
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':leave', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('200ms ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ left: '100%' }))
            ]),
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter', [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('300ms ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ left: '0%' }))
            ])
        ]),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(':enter', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animateChild)()),
    ])
]);


/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase */ 6797);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _loader_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loader.service */ 8555);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 6215);
/* harmony import */ var _interfaces_wallet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../interfaces/wallet */ 6845);
/* harmony import */ var _interfaces_tasks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../interfaces/tasks */ 3992);













let AuthService = class AuthService {
    constructor(afs, afAuth, router, ngZone, loader, http, alertController) {
        this.afs = afs;
        this.afAuth = afAuth;
        this.router = router;
        this.ngZone = ngZone;
        this.loader = loader;
        this.http = http;
        this.alertController = alertController;
        this.apiurl = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.apiUrl;
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject(null);
        this.userEmailVerify = false;
        this.userWallet = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject(new _interfaces_wallet__WEBPACK_IMPORTED_MODULE_3__.Wallet);
        this.userTasks = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject([new _interfaces_tasks__WEBPACK_IMPORTED_MODULE_4__.Task]);
        // providorsData
        this.googleConnected = false;
        this.facebookConnected = false;
        // this.linkSocialProfile();
        this.afAuth.authState.subscribe(user => {
            if (user) {
                const date = Date.now();
                // console.log(date);
                const dateBeforeWeek = date - ((24 * 60 * 60 * 1000) * 7);
                // console.log(dateBeforeWeek);
                const today = this.formatDate(date);
                const lastWeek = this.formatDate(dateBeforeWeek);
                this.userState = user;
                console.log(this.formatDate(date));
                if (!this.userDataSubscription) {
                    this.userDataSubscription = this.afs.doc(`users/${user.uid}`).valueChanges().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                        this.userData.next(data);
                        if (data && user) {
                            if (user.emailVerified == true && data.emailVerified == false) {
                                this.afs.doc(`users/${user.uid}`).set({ emailVerified: true }, { merge: true });
                            }
                        }
                        else {
                            const userDataForFirestore = {
                                photoURL: '',
                                city: '',
                                dob: '',
                                state: '',
                                phoneNumberVerify: false,
                                totalReferrals: 0,
                                completedTasks: 0,
                                country: 'IN',
                                uid: user.uid,
                                email: user.email,
                                phoneNumber: user.phoneNumber,
                                displayName: user.displayName,
                                emailVerified: false,
                                inviteCode: 'PL0011223344',
                                claim: 'user',
                                myInviteCode: this.getRandomNumbe()
                            };
                            yield this.afs.collection('users').doc(user.uid).set(userDataForFirestore, {
                                merge: true
                            });
                        }
                    }));
                    console.log(user);
                }
                if (!this.pointsWalletSubscription) {
                    this.pointsWalletSubscription = this.afs.doc(`pointsWallet/${user.uid}`).valueChanges().subscribe((wallet) => {
                        if (wallet) {
                            const id = user.uid;
                            const cWallet = Object.assign({ id }, wallet);
                            this.userWallet.next(cWallet);
                        }
                        else {
                            const newWallet = {
                                id: user.uid,
                                totalPoints: 0,
                                currentPoints: 0,
                                totalConvertedPoints: 0,
                                convertionRateInitial: 1,
                                totalConvertedAmount: 0,
                                withdrawlAmount: 0,
                                userUpi: '',
                                uid: user.uid
                            };
                            this.afs.collection(`pointsWallet/`).doc(user.uid).set(newWallet, { merge: true }).catch((err) => {
                                console.log(err);
                            });
                        }
                    });
                }
                // this.afs.collection('points', ref => ref.where('referedUserUid', '==', user.uid).where('type', '==', 'refer')).valueChanges().subscribe((data)=>{
                //   console.log(data);
                //   console.log(data.length)
                // })
                if (!this.tasksListSubscription) {
                    this.tasksListSubscription = this.afs.collectionGroup('tasks', (ref) => ref
                        .where('uid', '==', user.uid)
                        .where('allotedDate', '>=', lastWeek)
                        .where('allotedDate', '<=', today)
                        .orderBy('allotedDate', 'desc')).valueChanges().subscribe((tasks) => {
                        console.log(tasks);
                        this.userTasks.next(tasks);
                    });
                }
                user.providerData.some((data) => {
                    if (data.providerId == 'google.com') {
                        this.googleConnected = true;
                    }
                    if (data.providerId == 'facebook.com') {
                        this.facebookConnected = true;
                    }
                });
                // this.firebaseCapacitor.getToken()
                //   .then(token => console.log(`The token is ${token}`)) // save the token server-side and use it to push notifications to this device
                //   .catch(error => console.error('Error getting token', error));
                // this.firebaseCapacitor.onNotificationOpen()
                //   .subscribe(data => console.log(`User opened a notification ${data}`));
                // this.firebaseCapacitor.onTokenRefresh()
                //   .subscribe((token: string) => console.log(`Got a new token ${token}`));
                this.userUid = user.uid;
                this.userEmailVerify = user.emailVerified;
                localStorage.setItem('user', JSON.stringify(this.userState));
                JSON.parse(localStorage.getItem('user'));
            }
            else {
                localStorage.setItem('user', null);
                JSON.parse(localStorage.getItem('user'));
            }
        });
    }
    formatDate(date) {
        var d = new Date(date), month = '' + (d.getMonth() + 1), day = '' + d.getDate(), year = d.getFullYear();
        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;
        // return [day, month, year].join('-');
        return [day, month, year].join('');
    }
    signIn(payload) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return this.loader.showLoader().then(() => this.afAuth.signInWithEmailAndPassword(payload.email, payload.password)
                .then((result) => {
                // this.setUserData(result.user).then(() => {
                // this.router.navigate(['/main/dashboard']);
                // location.reload();
                // })
                this.ngZone.run(() => {
                    this.router.navigate(['/main']);
                });
                this.loader.stopLoader();
            }).catch((error) => {
                window.alert(error.message);
                this.loader.stopLoader();
            }));
        });
    }
    registration(payload) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return this.loader.showLoader().then(() => {
                this.afAuth.createUserWithEmailAndPassword(payload.email, payload.password).then((userdata) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                    const userRef = this.afs.doc(`users/${userdata.user.uid}`);
                    const userDataForAuth = {
                        uid: userdata.user.uid,
                        email: userdata.user.email,
                        phoneNumber: payload.newMobile,
                        displayName: payload.name,
                        emailVerified: false,
                    };
                    const userDataForFirestore = {
                        photoURL: '',
                        city: '',
                        dob: '',
                        state: '',
                        phoneNumberVerify: false,
                        totalReferrals: 0,
                        completedTasks: 0,
                        country: 'IN',
                        uid: userdata.user.uid,
                        email: userdata.user.email,
                        phoneNumber: payload.newMobile,
                        displayName: payload.name,
                        emailVerified: false,
                        inviteCode: payload.invitecode,
                        claim: 'user',
                        myInviteCode: this.getRandomNumbe()
                    };
                    (yield this.afAuth.currentUser).updateProfile(userDataForAuth).then(() => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                        yield userRef.set(userDataForAuth, {
                            merge: true
                        }).then(() => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                            yield this.afs.collection('users').doc(userdata.user.uid).set(userDataForFirestore, {
                                merge: true
                            }).then(() => {
                                this.SendVerificationMail().then(() => {
                                    this.presentAlert('Registration Success', 'Please verify your email before getting tasks.', 'success');
                                    this.loader.stopLoader();
                                    this.ngZone.run(() => {
                                        this.router.navigate(['/main']);
                                    });
                                });
                            }).catch(error => {
                                this.signOut();
                                this.loader.stopLoader();
                                console.log(error);
                                this.presentAlert('Registration Error', error.msg, 'error');
                            });
                        })).catch(error => {
                            this.signOut();
                            this.loader.stopLoader();
                            console.log(error);
                            this.presentAlert('Registration Error', error.msg, 'error');
                        });
                    })).catch(error => {
                        this.signOut();
                        this.loader.stopLoader();
                        console.log(error);
                        this.presentAlert('Registration Error', error.msg, 'error');
                    });
                })).catch(error => {
                    this.signOut();
                    this.loader.stopLoader();
                    console.log(error);
                    this.presentAlert('Registration Error', error.msg, 'error');
                });
            });
        });
    }
    getRandomNumbe() {
        const string = 'PL';
        return string + Date.now().toString().substring(0, 10);
    }
    SendVerificationMail() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return (yield this.afAuth.currentUser).sendEmailVerification();
        });
    }
    registrationAPIBASED(payload) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return this.loader.showLoader().then(() => {
                const userData = {
                    fullname: payload.name,
                    email: payload.email,
                    password: payload.password,
                    inviteCode: payload.invitecode,
                    phoneNumber: payload.newMobile
                };
                console.log(payload);
                console.log(userData);
                // return;
                const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpHeaders().set('requesttype', 'userApp');
                this.http.post(`${this.apiurl}auth/registration`, userData, { headers }).subscribe((result) => {
                    console.log(result);
                    if (!result.success) {
                        this.loader.stopLoader();
                        this.presentAlert('Registration Error', result.msg, 'error');
                    }
                    else {
                        this.loader.stopLoader();
                        this.presentAlert('Registration Success', 'Please login to start.', 'success');
                        this.router.navigate(['/auth/login']);
                        console.log(result);
                    }
                });
            });
        });
    }
    presentAlert(alertName, alertMessage, alertType) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: alertName,
                message: alertMessage,
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            if (alertType === 'success') {
                                this.router.navigate(['/auth/login']);
                                // location.reload();
                            }
                        }
                    }
                ]
            });
            yield alert.present();
            // const { role } = await alert.onDidDismiss();
            // console.log('onDidDismiss resolved with role', role);
        });
    }
    sendVerificationMail() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            // var phoneAuth = new firebase.auth.PhoneAuthProvider();
            // phoneAuth.verifyPhoneNumber
            return this.afAuth.currentUser.then(u => u.sendEmailVerification())
                .then(() => {
                this.router.navigate(['email-verification']);
            });
        });
    }
    forgotPassword(passwordResetEmail) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return this.afAuth.sendPasswordResetEmail(passwordResetEmail)
                .then(() => {
                window.alert('Password reset email sent, check your inbox.');
            }).catch((error) => {
                window.alert(error);
            });
        });
    }
    get isLoggedIn() {
        const user = JSON.parse(localStorage.getItem('user'));
        return (user !== null && user.emailVerified !== false) ? true : false;
    }
    // setUserData(user) {
    //   console.log(user);
    //   const userRef: AngularFirestoreDocument<any> = this.afs.doc(`users/${user.uid}`);
    //   this.userState2 = {
    //     uid: user.uid,
    //     email: user.email,
    //     phoneNumber: user.phoneNumber,
    //     displayName: user.displayName,
    //     photoURL: user.photoURL,
    //     emailVerified: user.emailVerified
    //   };
    //   return userRef.set(this.userState2, {
    //     merge: true
    //   });
    // }
    signOut() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return this.loader.showLoader().then(() => this.afAuth.signOut().then(() => {
                localStorage.removeItem('user');
                localStorage.clear();
                this.router.navigate(['/auth']);
                this.loader.stopLoader();
            }));
        });
    }
    updateProfile(payload) {
        const userRef = this.afs.doc(`users/${this.userUid}`);
        const userRef2 = this.afs.collection('users').doc(this.userUid);
        2;
        return userRef.set(payload, {
            merge: true
        }).then(() => {
            userRef2.set(payload, {
                merge: true
            });
        });
    }
    // updateAdditionalProfile(payload) {
    //   const userRef = this.afs.collection('users').doc(this.userUid);
    //   return userRef.set(payload, {
    //     merge: true
    //   });
    // }
    // link social profiles
    linkFacebook() {
        return this.loader.showLoader().then(() => this.linkSocialProfile(new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.FacebookAuthProvider()));
    }
    linkGoogle() {
        return this.loader.showLoader().then(() => this.linkSocialProfile(new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.GoogleAuthProvider()));
    }
    linkTwitter() {
        return this.loader.showLoader().then(() => this.linkSocialProfile(new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.TwitterAuthProvider()));
    }
    linkPhone() {
        return this.loader.showLoader().then(() => this.linkSocialProfile(new firebase__WEBPACK_IMPORTED_MODULE_0__.default.auth.PhoneAuthProvider()));
    }
    // not available providers
    // Instagram
    // LinkedIn
    linkSocialProfile(provider) {
        this.afAuth.currentUser.then((user) => {
            user.linkWithPopup(provider).then((response) => {
                // Accounts successfully linked.
                const data = {
                    credential: response.credential,
                    userX: response.user,
                    result: response
                };
                console.log(data);
                this.loader.stopLoader();
                location.reload();
            }).catch((error) => {
                window.alert(error.message);
                this.loader.stopLoader();
            });
        });
    }
    unlinkSocial(providerId) {
        this.afAuth.currentUser.then((user) => {
            user.unlink(providerId);
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_8__.AngularFirestore },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__.AngularFireAuth },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.NgZone },
    { type: _loader_service__WEBPACK_IMPORTED_MODULE_1__.LoaderService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.AlertController }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 8555:
/*!********************************************!*\
  !*** ./src/app/services/loader.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoaderService": () => (/* binding */ LoaderService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 476);



// import { SpinnerDialog } from '@ionic-native/spinner-dialog/ngx';
let LoaderService = class LoaderService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isShowingLoader = false;
    }
    showLoader() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            if (!this.isShowingLoader) {
                // this.spinnerDialog.show();
                this.isShowingLoader = true;
                this.loader = yield this.loadingController.create({
                    message: 'Please wait',
                });
                return yield this.loader.present();
            }
        });
    }
    stopLoader() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            // this.spinnerDialog.hide();
            if (this.loader) {
                this.loader.dismiss();
                this.loader = null;
                this.isShowingLoader = false;
            }
        });
    }
};
LoaderService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.LoadingController }
];
LoaderService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], LoaderService);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    firebaseConfig: {
        // apiKey: 'AIzaSyC7jBGFNesl0ZSkzMveKnjEyUXZrBzYKmU',
        // authDomain: 'localhost-project-2021.firebaseapp.com',
        // projectId: 'localhost-project-2021',
        // storageBucket: 'localhost-project-2021.appspot.com',
        // messagingSenderId: '121916967225',
        // appId: '1:121916967225:web:32857d0cc15303a67640e8'
        apiKey: "AIzaSyCN9QiM3FDbJ2ziO0XXLAol4fF5GXRLv3g",
        authDomain: "noworkneeded.firebaseapp.com",
        projectId: "noworkneeded",
        storageBucket: "noworkneeded.appspot.com",
        messagingSenderId: "266350440925",
        appId: "1:266350440925:web:d2fe77341b39c4839ec634",
        measurementId: "G-J2PXRC54X9",
    },
    apiUrl: 'https://damp-sands-53364.herokuapp.com/'
    // apiUrl: 'http://localhost:3000/'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 4608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		7321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		6108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		1489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		5830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		7757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		6911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		8695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		2239,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		8837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		4195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		1709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		5931,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		4513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		8056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		6272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		1855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		8708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		3527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		4694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		9222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		9921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		3122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		1602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		6164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		7162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		7896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		5043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		7802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		9072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		2191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		7110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 3069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 1106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <div [@routeAnimations]=\"prepareRoute(outlet)\">\n    <ion-router-outlet #outlet=\"outlet\"></ion-router-outlet>\n    <!-- <router-outlet #outlet=\"outlet\"></router-outlet> -->\n  </div>\n</ion-app>");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map