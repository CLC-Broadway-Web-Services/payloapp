package com.thevanar.paylo;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
