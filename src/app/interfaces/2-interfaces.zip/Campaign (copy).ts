export interface Campaign {
  company: string,
  completedHits: number,
  hits: number,
  platform: string,
  platformTask: string,
  status: string,
  url: string,
}
